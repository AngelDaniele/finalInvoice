package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.Description;
import com.demo.GenerateInvoiceFinal.model.Designation2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface Designation2Repository extends JpaRepository<Designation2,Integer> {

//    List<Designation2> findByDesignation1Designation1Id(int designation1Id);
//
//    List<Designation2> findByProject_ProjectTableId(int projectTableId);


//    @Query("SELECT d2 FROM Designation2 d2 " +
//            "JOIN d2.projectDesignation1 pd1 " +
//            "JOIN pd1.project p " +
//            "WHERE p.projectId = :projectId")
//    List<Designation2> findByProjectId(@Param("projectId") String projectId);
//}

}