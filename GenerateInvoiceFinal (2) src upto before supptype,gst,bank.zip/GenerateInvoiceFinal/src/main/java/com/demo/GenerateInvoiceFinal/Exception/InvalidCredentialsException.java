package com.demo.GenerateInvoiceFinal.Exception;

public class InvalidCredentialsException extends RuntimeException{



     public InvalidCredentialsException(String message){

         super(message);


     }

}
