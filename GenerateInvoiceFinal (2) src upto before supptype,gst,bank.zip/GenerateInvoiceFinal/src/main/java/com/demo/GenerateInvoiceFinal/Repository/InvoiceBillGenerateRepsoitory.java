package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.EmployeeWorking;
import com.demo.GenerateInvoiceFinal.model.Invoice;
import com.demo.GenerateInvoiceFinal.model.InvoiceBillGenerate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface InvoiceBillGenerateRepsoitory  extends JpaRepository<InvoiceBillGenerate,Integer> {
    List<InvoiceBillGenerate> findByProjectProjectNameIgnoreCase(String projectName);

    List<InvoiceBillGenerate> findByProjectClientClientNameIgnoreCase(String clientName);

    List<InvoiceBillGenerate> findByBillGenerate_BillGenerateTableIdIn(List<Integer> billGenerateTableIds);



        @Query("SELECT bg.billGenerateTableId FROM BillGenerate bg WHERE bg.billGenerateStartDate <= :endDate AND bg.billGenerateEndDate >= :startDate")
        List<Integer> findBillGenerateIdsWithinDateRange(@Param("startDate") Date startDate, @Param("endDate") Date endDate);
    }
