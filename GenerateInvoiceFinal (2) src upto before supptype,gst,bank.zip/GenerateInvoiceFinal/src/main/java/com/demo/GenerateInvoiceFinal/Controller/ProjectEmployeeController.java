package com.demo.GenerateInvoiceFinal.Controller;


import com.demo.GenerateInvoiceFinal.Repository.ProjectEmployeeRepository;
import com.demo.GenerateInvoiceFinal.Service.ProjectEmployeeService;
//import com.demo.GenerateInvoiceFinal.model.ProjectEmployeeUI;
import com.demo.GenerateInvoiceFinal.model.ProjectEmployees;
import com.demo.GenerateInvoiceFinal.model.UpdatedProjectEmployee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/projectEmployee")
public class ProjectEmployeeController {

    @Autowired
    private ProjectEmployeeService projectEmployeeService;

    @Autowired
    private ProjectEmployeeRepository projectEmployeeRepository;


    @GetMapping("/by-project/{projectId}")
    public List<ProjectEmployees> getProjectEmployeesByProjectId(@PathVariable String projectId) {
        return projectEmployeeService.getProjectEmployeesByProjectId(projectId);
    }

    @PostMapping("/{projectEmployeeId}/{userId}")
    public ResponseEntity<ProjectEmployees> updateProjectEmployee(@PathVariable int projectEmployeeId,
                                                                  @RequestBody UpdatedProjectEmployee updatedProjectEmployee, @PathVariable String userId ) {
        ProjectEmployees updatedEntity = projectEmployeeService.updateProjectEmployee(projectEmployeeId, updatedProjectEmployee,userId );
        return ResponseEntity.ok(updatedEntity);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<ProjectEmployees>> getAllProjectEmployee() {
        List<ProjectEmployees> projectEmployeesList = projectEmployeeService.getAllProjectEmployees();
        return new ResponseEntity<>(projectEmployeesList, HttpStatus.OK);
    }

//   @GetMapping("/getProjectEmployee")
//   public List<ProjectEmployees> getAllProjectEmployee(){
//       return projectEmployeeService.getProjectEmployee();
//  }

//
//    @PutMapping("/{projectEmployeeId}")
//   public ResponseEntity<ProjectEmployees> updateProjectEmployee(@PathVariable int projectEmployeeId,
//                                                          @RequestBody ProjectEmployees projectEmployee) {
//        ProjectEmployees updatedEntity = projectEmployeeService.updateProjectEmployee(projectEmployeeId, projectEmployee);     return ResponseEntity.ok(updatedEntity);
//   }

//    @PostMapping("/create/{userId}")
//    public ResponseEntity<ProjectEmployees> createProjectEmployee(@RequestBody ProjectEmployeeUI projectEmployeeUI,@PathVariable String userId) {
//
//            ProjectEmployees savedProjectEmployee = projectEmployeeService.saveProjectEmployee(projectEmployeeUI,userId);
//            return ResponseEntity.status(HttpStatus.CREATED).body(savedProjectEmployee);
//
//    }

//
//    public ProjectEmployees updateProjectEmployee(int projectEmployeeId, ProjectEmployees projectEmployee) {
//        ProjectEmployees existingProjectEmployees = projectEmployeeRepository.findById(projectEmployeeId)
//                .orElseThrow(() -> new EntityNotFoundException("ProjectEmployee not found with id: " + projectEmployeeId));
//
//        // Update only the specified fields
//        if (projectEmployee.getEmployee() != null && projectEmployee.getEmployee().getEmployeeId() != null) {
//            Employee employee = employeeRepository.findByEmployeeId(projectEmployee.getEmployee().getEmployeeId());
//            existingProjectEmployees.setEmployee(employee);
//        }
//
//        if (projectEmployee.getStartDate() != null) {
//            existingProjectEmployees.setStartDate(projectEmployee.getStartDate());
//        }
//
//        if (projectEmployee.getEndDate() != null) {
//            existingProjectEmployees.setEndDate(projectEmployee.getEndDate());
//        }
//
//        // Update other fields if needed...
//
//        return projectEmployeeRepository.save(existingProjectEmployees);
//    }



//        @PostMapping("/create")
//        public ResponseEntity<ProjectEmployees> createProjectEmployee(@RequestBody ProjectEmployeeUI projectEmployeeUI) {
//
//                ProjectEmployees projectEmployees = projectEmployeeService.saveProjectEmployee(projectEmployeeUI);
//                return new ResponseEntity<>(projectEmployees, HttpStatus.CREATED);
//
//        }

        // Add other endpoints for fetching, updating, or deleting project employees as needed







}



