package com.demo.GenerateInvoiceFinal.model;



public class ProjectHeadCountRequest {


    private String onsiteOrOffsite;
    private int numberOfResource;
    private int rate;
    private String location;
    private int projectTableId;
    private int designationId;

    public String getOnsiteOrOffsite() {
        return onsiteOrOffsite;
    }

    public void setOnsiteOrOffsite(String onsiteOrOffsite) {
        this.onsiteOrOffsite = onsiteOrOffsite;
    }

    public int getNumberOfResource() {
        return numberOfResource;
    }

    public void setNumberOfResource(int numberOfResource) {
        this.numberOfResource = numberOfResource;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getProjectTableId() {
        return projectTableId;
    }

    public void setProjectTableId(int projectTableId) {
        this.projectTableId = projectTableId;
    }

    public int getDesignationId() {
        return designationId;
    }

    public void setDesignationId(int designationId) {
        this.designationId = designationId;
    }
}
