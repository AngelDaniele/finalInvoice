package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "EditDesignationSummary")
public class EditDesignationSummary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EditDesignationSummaryId")
    private int EditDesignationSummaryId;

    @Column(name = "billGenerateTableId")
    private int billGenerateTableId;

    @Column(name = "designation")
    private String designation;

    @Column(name = "numberOfEmployees")
    private int numberOfEmployees;

    @Column(name = "totalRate")
    private int totalRate;

    @Column(name = "totalAmount")
    private int totalAmount;

    public int getEditDesignationSummaryId() {
        return EditDesignationSummaryId;
    }

    public void setEditDesignationSummaryId(int editDesignationSummaryId) {
        EditDesignationSummaryId = editDesignationSummaryId;
    }

    public int getBillGenerateTableId() {
        return billGenerateTableId;
    }

    public void setBillGenerateTableId(int billGenerateTableId) {
        this.billGenerateTableId = billGenerateTableId;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public int getNumberOfEmployees() {
        return numberOfEmployees;
    }

    public void setNumberOfEmployees(int numberOfEmployees) {
        this.numberOfEmployees = numberOfEmployees;
    }

    public int getTotalRate() {
        return totalRate;
    }

    public void setTotalRate(int totalRate) {
        this.totalRate = totalRate;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }
}
