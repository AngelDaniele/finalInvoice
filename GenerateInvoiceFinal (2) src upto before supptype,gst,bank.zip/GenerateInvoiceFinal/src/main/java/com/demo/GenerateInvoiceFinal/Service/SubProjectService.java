package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.BillGenerateRepository;
import com.demo.GenerateInvoiceFinal.Repository.ProjectRepository;
import com.demo.GenerateInvoiceFinal.Repository.SubProjectRepository;
import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.Project;
import com.demo.GenerateInvoiceFinal.model.SubProject;
import com.demo.GenerateInvoiceFinal.model.SubProjectUI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class SubProjectService {




        @Autowired
        private SubProjectRepository subProjectRepository;

        @Autowired
        private ProjectRepository projectRepository;


        @Autowired
        private BillGenerateRepository billGenerateRepository;

//
//        public SubProject saveSubProjectUIWithAutoUpdate(SubProjectUI subProjectUI, String userId) {
//
//            String projectId = subProjectUI.getProjectId();
//
//
//            Project project = projectRepository.findByProjectId(projectId);
//
//            if (project != null) {
//
//                SubProject subProject = new SubProject();
//                subProject.setSubProjectId(subProjectUI.getSubProjectId());
//                subProject.setStartDate(subProjectUI.getStartDate());
//                subProject.setEndDate(subProjectUI.getEndDate());
//                subProject.setBudget(subProjectUI.getBudget());
//                subProject.setRemaindingBudget(subProjectUI.getBudget());
//                subProject.setProject(project);
//                subProject.setUserId(userId);
//
//
//                subProject.setTimeStamp(LocalDateTime.now());
//
//
//
//                SubProject savedSubProject = subProjectRepository.save(subProject);
//
//
//                updateProjectDetails(project,subProjectUI.getBudget());
//
//
//
//                return savedSubProject;
//            } else {
//                throw new IllegalArgumentException("Project not found");
//            }
//        }

//
//        private void updateProjectDetails(Project project,int subProjectBudget) {
//            List<SubProject> subProjects = subProjectRepository.findByProject_ProjectId(project.getProjectId());
//
//            if (!subProjects.isEmpty()) {
//                LocalDate startDate = subProjects.stream()
//                        .map(SubProject::getStartDate)
//                        .min(LocalDate::compareTo)
//                        .orElse(null);
//                LocalDate endDate = subProjects.stream()
//                        .map(SubProject::getEndDate)
//                        .max(LocalDate::compareTo)
//                        .orElse(null);
//                int budget = subProjects.stream()
//                        .mapToInt(SubProject::getBudget)
//                        .sum();
//
//                int remaindingBudget = project.getRemaindingBudget()+subProjectBudget;
//
//
//                project.setStartDate(startDate);
//                project.setEndDate(endDate);
//                project.setBudget(budget);
//                project.setRemaindingBudget(remaindingBudget);
//                updateBillGenerateDetails(remaindingBudget, project);
//
//                projectRepository.save(project);
//
//
//
//            }
//        }

//    private void updateBillGenerateDetails(int remaindingBudget, Project project) {
//        List<BillGenerate> billGenerateList = billGenerateRepository.findByProject_ProjectId(project.getProjectId());
//
//        for (BillGenerate billGenerate : billGenerateList) {
//            billGenerate.setRemaindingBudget(remaindingBudget);
//            billGenerateRepository.save(billGenerate);
//        }
//    }


        public List<SubProject> getAllSubProjects() {
            return subProjectRepository.findAllWithProjectDetails();
        }




    }












