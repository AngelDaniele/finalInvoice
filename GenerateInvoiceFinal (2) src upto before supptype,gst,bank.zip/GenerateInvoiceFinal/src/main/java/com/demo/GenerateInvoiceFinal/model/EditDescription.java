package com.demo.GenerateInvoiceFinal.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name ="EditDescription")
public class EditDescription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EditDescriptionid")
    private Integer  EditDescriptionid;

    // Add a property to store billGenerateTableId
    @Transient // This annotation tells JPA not to persist this property to the database
    private Integer billGenerateTableId;

    @ManyToOne
    @JoinColumn(name = "billGenerateTableId")
    private BillGenerate billGenerate;


    @Column(name = "description")
    private String description;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "date")
    private LocalDate date;

    @Column(name = "amount")
    private Integer amount;

    @Column(name = "checked")
    private Boolean checked;

    public Integer getEditDescriptionid() {
        return EditDescriptionid;
    }

    public void setEditDescriptionid(Integer editDescriptionid) {
        EditDescriptionid = editDescriptionid;
    }

    public Integer getBillGenerateTableId() {
        return billGenerateTableId;
    }

    public void setBillGenerateTableId(Integer billGenerateTableId) {
        this.billGenerateTableId = billGenerateTableId;
    }

    public BillGenerate getBillGenerate() {
        return billGenerate;
    }

    public void setBillGenerate(BillGenerate billGenerate) {
        this.billGenerate = billGenerate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }
}
