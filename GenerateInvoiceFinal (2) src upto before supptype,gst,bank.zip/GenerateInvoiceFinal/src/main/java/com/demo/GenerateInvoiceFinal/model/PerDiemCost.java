package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "PerDiemCost")
public class PerDiemCost {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PDC")
    private int PDC;

    @ManyToOne
    @JoinColumn(name = "billGenerateTableId")
    private BillGenerate billGenerate;

    @ManyToOne
    @JoinColumn(name = "projectEmployeeId")
    private ProjectEmployees projectEmployees;

    @Column(name = "numberOfDays")
    private int numberOfDays;

    @Column(name = "totalAmount")
    private int totalAmount;

    @Column(name="SAC")
    private Integer SAC;

    @Column(name="description")
    private String description;


    public int getPDC() {
        return PDC;
    }

    public void setPDC(int PDC) {
        this.PDC = PDC;
    }

    public BillGenerate getBillGenerate() {
        return billGenerate;
    }

    public void setBillGenerate(BillGenerate billGenerate) {
        this.billGenerate = billGenerate;
    }

    public ProjectEmployees getProjectEmployees() {
        return projectEmployees;
    }

    public void setProjectEmployees(ProjectEmployees projectEmployees) {
        this.projectEmployees = projectEmployees;
    }

    public int getNumberOfDays() {
        return numberOfDays;
    }

    public void setNumberOfDays(int numberOfDays) {
        this.numberOfDays = numberOfDays;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Integer getSAC() {
        return SAC;
    }

    public void setSAC(Integer SAC) {
        this.SAC = SAC;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
