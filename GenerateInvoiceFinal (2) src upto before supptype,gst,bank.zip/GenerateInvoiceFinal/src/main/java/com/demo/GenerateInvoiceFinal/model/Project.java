package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="Project")
public class Project {




        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name="projectTableId")
        private int projectTableId;

        @Column(name="projectId")
        private String projectId;

        @Column(name="projectName")
        private String projectName;
        @Column(name="startDate")
        private LocalDate startDate;
        @Column(name="endDate")
        private LocalDate endDate;

        @ManyToOne
        @JoinColumn(name = "clientTableId")
        private Client client;

//    @ManyToOne
//    @JoinColumn(name = "designation1Id")
//    private Designation1 designation1;


        @Column(name="budget")
        private int budget;


    @Column(name="userId")
    private String userId;

    @Column(name="timeStamp")
    private LocalDateTime timeStamp;

//    @Column(name="checkBox")
//    private Boolean checkBox=false;


    @Column(name="costPerDiem")
    private Integer costPerDiem;

//    @Column(name="tdm")
//    private  Boolean tdm=false;

    @Column(name="currency")
    private String currency;


    public Project() {

        }

        public Project(String projectId) {
        }


        public int getProjectTableId() {
            return projectTableId;
        }

        public void setProjectTableId(int projectTableId) {
            this.projectTableId = projectTableId;
        }

        public String getProjectId() {
            return projectId;
        }

        public void setProjectId(String projectId) {
            this.projectId = projectId;
        }

        public LocalDate getStartDate() {
            return startDate;
        }

        public void setStartDate(LocalDate startDate) {
            this.startDate = startDate;
        }

        public LocalDate getEndDate() {
            return endDate;
        }

        public void setEndDate(LocalDate endDate) {
            this.endDate = endDate;
        }

        public String getProjectName() {
            return projectName;
        }

        public void setProjectName(String projectName) {
            this.projectName = projectName;
        }


        public Client getClient() {
            return client;
        }

        public void setClient(Client client) {
            this.client = client;
        }

        public int getBudget() {
            return budget;
        }

        public void setBudget(int budget) {
            this.budget = budget;
        }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }

//    public Boolean getCheckBox() {
//        return checkBox;
//    }
//
//    public void setCheckBox(Boolean checkBox) {
//        this.checkBox = checkBox;
//    }

    public Integer getCostPerDiem() {
        return costPerDiem;
    }

    public void setCostPerDiem(Integer costPerDiem) {
        this.costPerDiem = costPerDiem;
    }

//    public Boolean getTdm() {
//        return tdm;
//    }
//
//    public void setTdm(Boolean tdm) {
//        this.tdm = tdm;
//    }


    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

//    public Designation1 getDesignation1() {
//        return designation1;
//    }
//
//    public void setDesignation1(Designation1 designation1) {
//        this.designation1 = designation1;
//    }
}

