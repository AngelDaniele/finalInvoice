package com.demo.GenerateInvoiceFinal.Exception;

public class GSTNotFoundException extends RuntimeException {

    public GSTNotFoundException(String message){
        super(message);
    }
}
