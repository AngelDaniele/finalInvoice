package com.demo.GenerateInvoiceFinal;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class GenerateInvoiceFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenerateInvoiceFinalApplication.class, args);
	}

}
