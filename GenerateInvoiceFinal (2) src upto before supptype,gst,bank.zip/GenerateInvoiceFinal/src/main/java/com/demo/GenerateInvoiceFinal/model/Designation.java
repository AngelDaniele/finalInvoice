package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "Designation")
public class Designation {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DesignationId")
    private Integer DesignationId;


    @Column(name="designation")
    private String designation;

    public Integer getDesignationId() {
        return DesignationId;
    }

    public void setDesignationId(Integer designationId) {
        DesignationId = designationId;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
}
