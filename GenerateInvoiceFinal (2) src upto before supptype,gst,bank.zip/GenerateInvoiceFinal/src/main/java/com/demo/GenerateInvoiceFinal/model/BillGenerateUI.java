package com.demo.GenerateInvoiceFinal.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class BillGenerateUI {


    private String projectId;



    private LocalDate billGenerateStartDate;

    private LocalDate billGenerateEndDate;
    private String userId;
    private LocalDateTime timeStamp;

    private int  SAC;



    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }



    public LocalDate getBillGenerateStartDate() {
        return billGenerateStartDate;
    }

    public void setBillGenerateStartDate(LocalDate billGenerateStartDate) {
        this.billGenerateStartDate = billGenerateStartDate;
    }

    public LocalDate getBillGenerateEndDate() {
        return billGenerateEndDate;
    }

    public void setBillGenerateEndDate(LocalDate billGenerateEndDate) {
        this.billGenerateEndDate = billGenerateEndDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }

    public int getSAC() {
        return SAC;
    }

    public void setSAC(int SAC) {
        this.SAC = SAC;
    }

}
