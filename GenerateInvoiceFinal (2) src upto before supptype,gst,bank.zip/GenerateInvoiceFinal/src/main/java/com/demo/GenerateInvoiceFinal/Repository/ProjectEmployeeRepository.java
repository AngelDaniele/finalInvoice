package com.demo.GenerateInvoiceFinal.Repository;


import com.demo.GenerateInvoiceFinal.model.ProjectEmployees;
import com.demo.GenerateInvoiceFinal.model.ProjectHeadCount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProjectEmployeeRepository extends JpaRepository<ProjectEmployees,Integer> {


    List<ProjectEmployees> findByProjectHeadCount(ProjectHeadCount projectHeadCount);

    List<ProjectEmployees> findByProjectHeadCount_Project_ProjectId(String projectId);
//    List<ProjectEmployees> findByProject_ProjectId(String projectId);

//    ProjectEmployees  findById(int projectEmployeeId);
}




