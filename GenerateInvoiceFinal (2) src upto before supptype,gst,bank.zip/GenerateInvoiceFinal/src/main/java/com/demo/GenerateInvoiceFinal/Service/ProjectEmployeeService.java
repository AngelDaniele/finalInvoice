package com.demo.GenerateInvoiceFinal.Service;


import com.demo.GenerateInvoiceFinal.Exception.EmployeeNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.*;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class ProjectEmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectEmployeeRepository projectEmployeeRepository;

    @Autowired
    private EmployeeWorkingRepository employeeWorkingRepository;


    public List<ProjectEmployees> getProjectEmployeesByProjectId(String projectId) {
        return projectEmployeeRepository.findByProjectHeadCount_Project_ProjectId(projectId);
    }
    public ProjectEmployees updateProjectEmployee(int projectEmployeeId, UpdatedProjectEmployee updatedProjectEmployee, String userId) {
        ProjectEmployees existingProjectEmployees = projectEmployeeRepository.findById(projectEmployeeId)
                .orElseThrow(() -> new EntityNotFoundException("ProjectEmployee not found with id: " + projectEmployeeId));


            // Find the Employee using the provided employeeId



            // Find the Employee using the provided employeeId
            Employee employee = employeeRepository.findByEmployeeId(updatedProjectEmployee.getEmployee());

            // Check if the employee is found

                // Set the found employee in ProjectEmployees
                existingProjectEmployees.setEmployee(employee);


            // Check if the employee is found

                // Set the found employee in ProjectEmployees





            existingProjectEmployees.setStartDate(updatedProjectEmployee.getStartDate());


        existingProjectEmployees.setEndDate(updatedProjectEmployee.getEndDate());

        // Update other fields if needed...

        existingProjectEmployees.setUserId(userId);
        existingProjectEmployees.setTimeStamp(LocalDateTime.now());
        return projectEmployeeRepository.save(existingProjectEmployees);
    }


//
//
//    public ProjectEmployees updateProjectEmployee(int projectEmployeeId, ProjectEmployees projectEmployee) {
//        ProjectEmployees existingProjectEmployees = projectEmployeeRepository.findById(projectEmployeeId)
//                .orElseThrow(() -> new EntityNotFoundException("projectEmployeenot found with id: " + projectEmployeeId));
//
//        // Update only the specified fields
//        if (projectEmployee.getEmployee().getEmployeeId() != null) {
//            Employee employee = employeeRepository.findByEmployeeId(projectEmployee.getEmployee().getEmployeeId());
//            existingProjectEmployees.setEmployee(employee);
//        }
//
//        if (projectEmployee.getStartDate() != null) {
//            existingProjectEmployees.setStartDate(projectEmployee.getStartDate());
//        }
//
//        if (projectEmployee.getEndDate() != null) {
//            existingProjectEmployees.setEndDate(projectEmployee.getEndDate());
//        }
//
//        // Update other fields if needed...
//
//        return projectEmployeeRepository.save(existingProjectEmployees);
//    }





//    public Designation2 updateDesignation2(int designation2Id, UpdatedDesignation2 updatedDesignation2) {
//        Designation2 existingDesignation2 = designation2Repository.findById(designation2Id)
//                .orElseThrow(() -> new EntityNotFoundException("Designation2 not found with id: " + designation2Id));
//
//        // Update only the specified fields
//        if (updatedDesignation2.getEmployeeId() != null) {
//            Employee employee = employeeRepository.findByEmployeeId(updatedDesignation2.getEmployeeId());
//            existingDesignation2.setEmployee(employee);
//        }
//
//        if (updatedDesignation2.getStartDate() != null) {
//            existingDesignation2.setStartDate(updatedDesignation2.getStartDate());
//        }
//
//        if (updatedDesignation2.getEndDate() != null) {
//            existingDesignation2.setEndDate(updatedDesignation2.getEndDate());
//        }
//
//        // Update other fields if needed...
//
//        return designation2Repository.save(existingDesignation2);
//    }
//

    //
//    public ProjectEmployees saveProjectEmployee(ProjectEmployeeUI projectEmployeeUI, String userId) {
//        Employee employee = employeeRepository.findByEmployeeId(projectEmployeeUI.getEmployeeId());
//        Project project = projectRepository.findByProjectId(projectEmployeeUI.getProjectId());
//
//        // Create and save the ProjectEmployees
//        ProjectEmployees projectEmployees = new ProjectEmployees();
//        projectEmployees.setEmployee(employee);
//        projectEmployees.setProject(project);
//        projectEmployees.setUserId(userId);
//
//
//        projectEmployees.setTimeStamp(LocalDateTime.now());
//        projectEmployeeRepository.save(projectEmployees);
//
//        // Generate random dates
//        LocalDate projectStartDate = project.getStartDate();
//        LocalDate projectEndDate = project.getEndDate();
//        int numDatesToGenerate = 15; // Number of random dates per month
//
//        List<LocalDate> randomDates = new ArrayList<>();
//        Random random = new Random();
//
//        LocalDate currentDate = projectStartDate;
//        while (currentDate.isBefore(projectEndDate)) {
//            // Generate 15 random dates for the current month
//            for (int i = 0; i < numDatesToGenerate; i++) {
//                LocalDate randomDate;
//                do {
//                    // Generate a random date within the current month
//                    randomDate = currentDate.plusDays(random.nextInt(currentDate.lengthOfMonth()));
//                } while (randomDates.contains(randomDate)); // Ensure uniqueness
//
//                randomDates.add(randomDate);
//            }
//
//            // Move to the next month
//            currentDate = currentDate.plusMonths(1);
//        }
//
//
//        Collections.sort(randomDates);
//
//        // Save the sorted dates in EmployeeWorking records
//        for (LocalDate randomDate : randomDates) {
//            EmployeeWorking employeeWorking = new EmployeeWorking(randomDate);
//            employeeWorking.setProjectEmployees(projectEmployees);
//
//            employeeWorkingRepository.save(employeeWorking);
//        }
//
//
//        ProjectEmployees response = new ProjectEmployees();
//        response.setProjectEmployeeId(projectEmployees.getProjectEmployeeId());
//        response.setProject(projectEmployees.getProject());
//        response.setEmployee(projectEmployees.getEmployee());
//
//
//        return response;
//    }






//    public List<ProjectEmployees> getProjectEmployee() {
//        List<ProjectEmployees> list = projectEmployeeRepository.findAll();
//        if (list != null) {
//            return list;
//
//        }
//        throw new EmployeeNotFoundException("Project is not yet assigned");
//    }

    public List<ProjectEmployees> getAllProjectEmployees() {
        List<ProjectEmployees> projectEmployeesList = projectEmployeeRepository.findAll();
        if (!projectEmployeesList.isEmpty()) {
            return projectEmployeesList;
        }
        throw new EmployeeNotFoundException("Project employees are not yet assigned");
    }
//    public List<ProjectEmployees> getAllProjectEmployeesByProjectId(String projectId) {
//        return projectEmployeeRepository.findByProject_ProjectId(projectId);
//    }

}




