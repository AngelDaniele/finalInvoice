package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.Description;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

public interface DescriptionRepository extends JpaRepository<Description,Integer> {
    List<Description> findAllByBillGenerate_BillGenerateTableId(int billGenerateTableId);

//
//    @Query("SELECT CASE WHEN COUNT(d) > 0 THEN true ELSE false END FROM Description d WHERE d.description = :description AND d.billGenerate.billGenerateTableId = :billGenerateTableId")
//    boolean customExistsByDescriptionAndBillGenerate_Id(@Param("description") String description, @Param("billGenerateTableId") Integer billGenerateTableId);
//
//}

    @Query("SELECT CASE WHEN COUNT(d) > 0 THEN true ELSE false END FROM Description d WHERE d.description = :description AND d.billGenerate.billGenerateTableId = :billGenerateTableId AND d.date = :date")
    boolean customExistsByDescriptionAndBillGenerate_IdAndDate(@Param("description") String description, @Param("billGenerateTableId") Integer billGenerateTableId, @Param("date") LocalDate date);

//    @Query("SELECT d FROM Description d WHERE d.billGenerate.billGenerateTableId = :billGenerateTableId")
//    List<Description> findByBillGenerateTableId(@Param("billGenerateTableId") Integer billGenerateTableId);



//    Collection<?> findUnionDataByBillGenerateTableId(Integer billGenerateTableId);
}

//    List<Description> findByBillGenerateTableId(Integer billGenerateTableId);

