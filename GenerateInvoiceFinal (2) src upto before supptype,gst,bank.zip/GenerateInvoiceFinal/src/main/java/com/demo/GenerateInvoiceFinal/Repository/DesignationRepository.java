package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.Description;
import com.demo.GenerateInvoiceFinal.model.Designation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DesignationRepository extends JpaRepository<Designation,Integer> {

    Designation findByDesignationIgnoreCase(String designationName);

   
}
