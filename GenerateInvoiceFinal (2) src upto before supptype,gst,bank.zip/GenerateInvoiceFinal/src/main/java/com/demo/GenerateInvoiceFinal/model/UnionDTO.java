package com.demo.GenerateInvoiceFinal.model;

import java.time.LocalDate;

public class UnionDTO {



    private String item; // Assuming this is a common field
    private String description;
    private LocalDate startDate;
    private LocalDate EndDate;
    private Integer SAC;

    // Fields from BGTable
    private Integer quantity;
    private Integer rate;

    // Fields from PerDiemCost


    // Fields from Description
    private Integer amount;




    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return EndDate;
    }

    public void setEndDate(LocalDate endDate) {
        EndDate = endDate;
    }

    public Integer getSAC() {
        return SAC;
    }

    public void setSAC(Integer SAC) {
        this.SAC = SAC;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }



    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }
}
