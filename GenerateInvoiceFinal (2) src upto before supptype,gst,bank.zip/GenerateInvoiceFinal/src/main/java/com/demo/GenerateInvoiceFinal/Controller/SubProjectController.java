package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.SubProjectService;
import com.demo.GenerateInvoiceFinal.model.SubProject;
import com.demo.GenerateInvoiceFinal.model.SubProjectUI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/subprojects")
public class SubProjectController {





        @Autowired
        private SubProjectService subProjectService;
//
//        @PostMapping("/save/{userId}")
//        public ResponseEntity<SubProject> saveSubProjectUI(@RequestBody SubProjectUI subProjectUI, @PathVariable String userId) {
//            SubProject savedSubProject = subProjectService.saveSubProjectUIWithAutoUpdate(subProjectUI, userId);
//            return ResponseEntity.ok(savedSubProject);
//        }

        @GetMapping("/all")
        public ResponseEntity<List<SubProject>> getAllSubProjects() {
            List<SubProject> subProjects = subProjectService.getAllSubProjects();
            return ResponseEntity.ok(subProjects);
        }
    }








