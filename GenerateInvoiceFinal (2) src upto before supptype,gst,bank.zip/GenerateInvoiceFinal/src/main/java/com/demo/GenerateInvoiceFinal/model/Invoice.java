package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "Invoice")
public class Invoice {




        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "invoiceNumber")
        private int invoiceNumber;




        @Column(name = "billGenerateTableId")
        private int billGenerateTableId;

        @Column(name = "cgst")
        private BigDecimal cgst;

        @Column(name = "sgst")
        private BigDecimal sgst;

        @Column(name = "subtotal")
        private BigDecimal subtotal;

        @Column(name = "totalAmount")
        private BigDecimal totalAmount;

    @Column(name = "totalCharges")
    private BigDecimal totalCharges;

    @Column(name = "grandTotal ")
    private BigDecimal grandTotal ;

    @Column(name="userId")
    private String userId;

    @Column(name="timeStamp")
    private LocalDateTime timeStamp;

    @Column(name = "RFM")
    private boolean RFM;

    @Column(name = "status")
    private String status;


    @ManyToOne
    @JoinColumn(name = "gstId")
    private GST gst;

    @ManyToOne
    @JoinColumn(name = "supTyId")
    private SupplyType supplyType;

    @ManyToOne
    @JoinColumn(name = "bankId")
    private Bank bank;



    // Getters and setters

        public int getInvoiceNumber() {
            return invoiceNumber;
        }

        public void setInvoiceNumber(int invoiceNumber) {
            this.invoiceNumber = invoiceNumber;
        }

        public int getBillGenerateTableId() {
            return billGenerateTableId;
        }

        public void setBillGenerateTableId(int billGenerateTableId) {
            this.billGenerateTableId = billGenerateTableId;
        }

        public BigDecimal getCgst() {
            return cgst;
        }

        public void setCgst(BigDecimal cgst) {
            this.cgst = cgst;
        }

        public BigDecimal getSgst() {
            return sgst;
        }

        public void setSgst(BigDecimal sgst) {
            this.sgst = sgst;
        }

        public BigDecimal getSubtotal() {
            return subtotal;
        }

        public void setSubtotal(BigDecimal subtotal) {
            this.subtotal = subtotal;
        }

        public BigDecimal getTotalAmount() {
            return totalAmount;
        }

        public void setTotalAmount(BigDecimal totalAmount) {
            this.totalAmount = totalAmount;
        }

    public BigDecimal getTotalCharges() {
        return totalCharges;
    }

    public void setTotalCharges(BigDecimal totalCharges) {
        this.totalCharges = totalCharges;
    }

    public BigDecimal getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(BigDecimal grandTotal) {
        this.grandTotal = grandTotal;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }

    public boolean isRFM() {
        return RFM;
    }

    public void setRFM(boolean RFM) {
        this.RFM = RFM;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }




    public GST getGst() {
        return gst;
    }


    public void setGst(GST gst) {
        this.gst = gst;
    }

    public SupplyType getSupplyType() {
        return supplyType;
    }

    public void setSupplyType(SupplyType supplyType) {
        this.supplyType = supplyType;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }}


