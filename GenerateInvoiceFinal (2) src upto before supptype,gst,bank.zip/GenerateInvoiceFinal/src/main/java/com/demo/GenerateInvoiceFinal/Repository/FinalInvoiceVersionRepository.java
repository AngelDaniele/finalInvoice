package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.FinalInvoiceVersion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinalInvoiceVersionRepository extends JpaRepository<FinalInvoiceVersion,Integer> {


}
