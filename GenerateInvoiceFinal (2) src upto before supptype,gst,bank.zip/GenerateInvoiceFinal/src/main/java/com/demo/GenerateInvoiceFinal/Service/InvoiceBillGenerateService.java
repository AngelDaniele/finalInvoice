package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.BillGenerateRepository;
import com.demo.GenerateInvoiceFinal.Repository.InvoiceBillGenerateRepsoitory;
import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.Invoice;
import com.demo.GenerateInvoiceFinal.model.InvoiceBillGenerate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class InvoiceBillGenerateService {

    @Autowired
    InvoiceBillGenerateRepsoitory invoiceBillGenerateRepository;

     @Autowired
    BillGenerateRepository billGenerateRepository;

    public List<InvoiceBillGenerate> getDetailsByProjectName(String projectName) {
        return invoiceBillGenerateRepository.findByProjectProjectNameIgnoreCase(projectName);
    }


    public List<InvoiceBillGenerate> getDetailsByClientName(String clientName) {
        return invoiceBillGenerateRepository.findByProjectClientClientNameIgnoreCase(clientName);
    }



//    public List<InvoiceBillGenerate> findInvoicesByDate(LocalDate date) {
//        List<BillGenerate> billGenerates = billGenerateRepository.findByBillGenerateStartDateLessThanEqualAndBillGenerateEndDateGreaterThanEqual(date, date);
//        if (!billGenerates.isEmpty()) {
//            List<Integer> billGenerateTableIds = billGenerates.stream()
//                    .map(BillGenerate::getBillGenerateTableId)
//                    .collect(Collectors.toList());
//            return invoiceBillGenerateRepository.findByBillGenerate_BillGenerateTableIdIn(billGenerateTableIds);
//        } else {
//            // Return an empty list if no matching records are found
//            return Collections.emptyList();
//        }
//    }




}
