package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "Bank")
public class Bank {



        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "bankId")
        private int bankId;

        @Column(name = "bankName")
        private String bankName;

        @Column(name = "bankAccountNo")
        private long bankAccountNo;

        @Column(name = "bankIFSCCode")
        private String bankIFSCCode;

        @Column(name = "bankSwiftCode")
        private String bankSwiftCode;

        @Column(name = "bankAddress")
        private String bankAddress;

        @Column(name = "bankAccountType")
        private String bankAccountType;

        @Column(name = "bankAccountHolder")
        private String bankAccountHolder;

        public Bank() {
        }

        // Getters and setters

        public int getBankId() {
            return bankId;
        }

        public void setBankId(int bankId) {
            this.bankId = bankId;
        }

        public String getBankName() {
            return bankName;
        }

        public void setBankName(String bankName) {
            this.bankName = bankName;
        }

        public long getBankAccountNo() {
            return bankAccountNo;
        }

        public void setBankAccountNo(long bankAccountNo) {
            this.bankAccountNo = bankAccountNo;
        }

        public String getBankIFSCCode() {
            return bankIFSCCode;
        }

        public void setBankIFSCCode(String bankIFSCCode) {
            this.bankIFSCCode = bankIFSCCode;
        }

        public String getBankSwiftCode() {
            return bankSwiftCode;
        }

        public void setBankSwiftCode(String bankSwiftCode) {
            this.bankSwiftCode = bankSwiftCode;
        }

        public String getBankAddress() {
            return bankAddress;
        }

        public void setBankAddress(String bankAddress) {
            this.bankAddress = bankAddress;
        }

        public String getBankAccountType() {
            return bankAccountType;
        }

        public void setBankAccountType(String bankAccountType) {
            this.bankAccountType = bankAccountType;
        }

        public String getBankAccountHolder() {
            return bankAccountHolder;
        }

        public void setBankAccountHolder(String bankAccountHolder) {
            this.bankAccountHolder = bankAccountHolder;
        }
    }



