package com.demo.GenerateInvoiceFinal.Repository;
import com.demo.GenerateInvoiceFinal.model.Project;
import com.demo.GenerateInvoiceFinal.model.ProjectHeadCount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProjectHeadCountRepository extends JpaRepository<ProjectHeadCount,Integer> {
//    ProjectHeadCount findByProject(Project project);

    List<ProjectHeadCount> findByProject(Project project);

//    List<Designation1> findByProjectProjectTableId(int projectTableId);
//
//    List<Designation1> findByProjectProjectId(String projectId);
}
