package com.demo.GenerateInvoiceFinal.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "Description")
public class Description {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;


    @Transient // This annotation tells JPA not to persist this property to the database
    private Integer billGenerateTableId;

    @ManyToOne
    @JoinColumn(name = "billGenerateTableId")
    private BillGenerate billGenerate;


    @Column(name = "description")
    private String description;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(name = "date")
    private LocalDate date;

    @Column(name = "amount")
    private Integer amount;

//    @Column(name = "checked")
//    private Boolean checked;

    @JoinColumn(name="SAC")
    private Integer SAC;


    public Description() {
    }

    public Description( String description,LocalDate date, Integer amount) {

        this.description = description;
        this.date = date;
        this.amount = amount;
//        this.checked = checked;
    }

    // Getters and setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BillGenerate getBillGenerate() {
        return billGenerate;
    }

    public void setBillGenerate(BillGenerate billGenerate) {
        this.billGenerate = billGenerate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

//    public Boolean getChecked() {
//        return checked;
//    }
//
//    public void setChecked(Boolean checked) {
//        this.checked = checked;
//    }

    public Integer getBillGenerateTableId() {
        return billGenerateTableId;
    }

    public void setBillGenerateTableId(Integer billGenerateTableId) {
        this.billGenerateTableId = billGenerateTableId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getSAC() {
        return SAC;
    }

    public void setSAC(Integer SAC) {
        this.SAC = SAC;
    }

}



