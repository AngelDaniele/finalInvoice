package com.demo.GenerateInvoiceFinal.Service;


import com.demo.GenerateInvoiceFinal.Exception.ClientNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.ClientRepository;
import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.List;

@Service
public class ClientService {
    @Autowired
    ClientRepository clientRepository;


    public Client saveClient(Client client, String userId) {
        client.setUserId(userId);

        // Set the current date and time
        client.setTimeStamp(LocalDateTime.now());
        return clientRepository.save(client);

    }

    public List<Client> getAllClient() {

        List<Client> list = clientRepository.findAll();

        if (list.size() > 0) {
            return list;
        } else
            throw new ClientNotFoundException("No Client in catalog");
    }



    public Client updateProductInCatalog(Client client, int key) throws ClientNotFoundException {
        Optional<Client> optionalProduct = clientRepository.findById(key);

        if (optionalProduct.isPresent()) {
            Client existingClient = optionalProduct.get();
            existingClient.setClientId(client.getClientId());
            existingClient.setClientName(client.getClientName());
            existingClient.setClientAddress(client.getClientAddress());
            existingClient.setPhoneNumber(client.getPhoneNumber());
            existingClient.setGmailId(client.getGmailId());

            Client updatedClient = clientRepository.save(existingClient);
            return updatedClient;
        } else {
            throw new ClientNotFoundException("Product not found with the given id");
        }
    }


//    public String deleteClient(Integer id) throws ClientNotFoundException {
//
//        Optional<Client> opt=	clientRepository.findById(id);
//
//        if(opt.isPresent()) {
//            Client client = opt.get();
//            clientRepository.delete(client);
//            return "Client deleted";
//        } else
//            throw new ClientNotFoundException("Client not found with given id");
//    }

    public String deleteClient(Integer id) throws ClientNotFoundException {

        Optional<Client> opt=	clientRepository.findById(id);

        if(opt.isPresent()) {
            Client client = opt.get();
            clientRepository.delete(client);
            return "Client deleted";
        } else
            throw new ClientNotFoundException("Client not found with given id");
    }

    public Client getClientById(int clientTableId) {
        Optional<Client> opt = clientRepository.findById(clientTableId);
        if (opt.isPresent()) {
            return opt.get();
        }

        else
            throw new ClientNotFoundException("Client not found with given id");
    }

    public Client findByClientId(String clientId) {

        return clientRepository.findByClientId(clientId);
    }

//    private Client getClientById(Integer clientTableId) {
//
//        Optional<Client> opt = clientRepository.findById(clientTableId);
//
//        if (opt.isPresent()) {
//            return opt.get();
//        } else {
//            return null;
//        }
//    }




}
