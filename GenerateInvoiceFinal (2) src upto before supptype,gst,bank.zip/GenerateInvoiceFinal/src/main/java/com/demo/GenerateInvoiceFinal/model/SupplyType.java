package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "SupplyType")
public class SupplyType {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "supTyId")
    private int supTyId;

    @Column(name = "supTyCode")
    private String supTyCode;

    public SupplyType() {
    }

    // Getters and setters

    public int getSupTyId() {
        return supTyId;
    }

    public void setSupTyId(int supTyId) {
        this.supTyId = supTyId;
    }

    public String getSupTyCode() {
        return supTyCode;
    }

    public void setSupTyCode(String supTyCode) {
        this.supTyCode = supTyCode;
    }
}
