package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="ProjectEmployees")
public class ProjectEmployees {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="projectEmployeeId")
    private int projectEmployeeId;


    @ManyToOne
    @JoinColumn(name = "employeeTableId")
    private Employee employee;

    @ManyToOne
    @JoinColumn(name = "projectHeadCountId")
    private ProjectHeadCount projectHeadCount;

    @Column(name="userId")
    private String userId;

    @Column(name="timeStamp")
    private LocalDateTime timeStamp;

    @Column(name = "startDate")
    private LocalDate startDate;

    @Column(name = "endDate")
    private LocalDate endDate;


    public int getProjectEmployeeId() {
        return projectEmployeeId;
    }

    public void setProjectEmployeeId(int projectEmployeeId) {
        this.projectEmployeeId = projectEmployeeId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public ProjectHeadCount getProjectHeadCount() {
        return projectHeadCount;
    }

    public void setProjectHeadCount(ProjectHeadCount projectHeadCount) {
        this.projectHeadCount = projectHeadCount;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}

