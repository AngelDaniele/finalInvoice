package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Repository.PerDiemCostRepository;
import com.demo.GenerateInvoiceFinal.Service.PerDiemCostService;
import com.demo.GenerateInvoiceFinal.model.PerDiemCost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/perDiemCost")
public class PerDiemCostController {

    @Autowired
    PerDiemCostService perDiemCostService;

    @Autowired
    PerDiemCostRepository perDiemCostRepository;







 @PostMapping("/update/{pdc}/{billGenerateTableId}")
public ResponseEntity<PerDiemCost> updatePerDiemCost(
        @PathVariable int pdc,
        @PathVariable int billGenerateTableId,
        @RequestBody PerDiemCost updatedPerDiemCost) {

    PerDiemCost result = perDiemCostService.updatePerDiemCost(pdc, billGenerateTableId, updatedPerDiemCost);
    return new ResponseEntity<>(result, HttpStatus.OK);
}

    @GetMapping("/by-bill-generate/{billGenerateTableId}")
    public ResponseEntity<List<PerDiemCost>> getPerDiemCostsByBillGenerateTableId(
            @PathVariable("billGenerateTableId") int billGenerateTableId) {
        List<PerDiemCost> perDiemCosts = perDiemCostService.getAllPerDiemCostsByBillGenerateTableId(billGenerateTableId);
        return ResponseEntity.ok(perDiemCosts);
    }



}