package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "ProjectHeadCount")
public class ProjectHeadCount {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "projectHeadCountId")
    private int projectHeadCountId;

    @Column(name = "onsiteOrOffsite")
    private String onsiteOrOffsite;


    @Column(name = "numberOfResource")
    private int numberOfResource;

    @Column(name = "rate")
    private int rate;

    @Column(name = "location", length = 300)
    private String location;


    @ManyToOne
    @JoinColumn(name = "projectTableId")
    private Project project;

    @ManyToOne
    @JoinColumn(name = "designationId")
    private Designation designation;

    public int getProjectHeadCountId() {
        return projectHeadCountId;
    }

    public void setProjectHeadCountId(int projectHeadCountId) {
        this.projectHeadCountId = projectHeadCountId;
    }

    public int getNumberOfResource() {
        return numberOfResource;
    }

    public void setNumberOfResource(int numberOfResource) {
        this.numberOfResource = numberOfResource;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getOnsiteOrOffsite() {
        return onsiteOrOffsite;
    }

    public void setOnsiteOrOffsite(String onsiteOrOffsite) {
        this.onsiteOrOffsite = onsiteOrOffsite;
    }


    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Designation getDesignation() {
        return designation;
    }

    public void setDesignation(Designation designation) {
        this.designation = designation;
    }
}


