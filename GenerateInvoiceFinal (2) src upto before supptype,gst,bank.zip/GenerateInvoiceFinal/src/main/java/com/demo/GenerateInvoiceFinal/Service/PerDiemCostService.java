package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Exception.ProjectNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.PerDiemCostRepository;
import com.demo.GenerateInvoiceFinal.model.BGTable;
import com.demo.GenerateInvoiceFinal.model.PerDiemCost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class PerDiemCostService {

    @Autowired
    private PerDiemCostRepository perDiemCostRepository;

//    public PerDiemCost updatePerDiemCost(int pdc, int billGenerateTableId, int projectEmployeeId, int newNumberOfDays, int newTotalAmount) {
//        PerDiemCost existingPerDiemCost = perDiemCostRepository.findById(pdc)
//                .orElseThrow(() -> new ProjectNotFoundException("PerDiemCost not found"));
//
//        if (existingPerDiemCost.getBillGenerate().getBillGenerateTableId() == billGenerateTableId
//                && existingPerDiemCost.getProjectEmployees().getProjectEmployeeId() == projectEmployeeId) {
//            existingPerDiemCost.setNumberOfDays(newNumberOfDays);
//            existingPerDiemCost.setTotalAmount(newTotalAmount);
//            return perDiemCostRepository.save(existingPerDiemCost);
//        } else {
//            throw new IllegalArgumentException("billGenerateTableId or projectEmployeeId does not match the existing record");
//        }
//    }


  public PerDiemCost updatePerDiemCost(int PDC, int billGenerateTableId, PerDiemCost updatedPDC) {
       Optional<PerDiemCost> existingPerDiemCostOptional = perDiemCostRepository.findById(PDC);

       if (existingPerDiemCostOptional.isPresent()) {
           PerDiemCost existingPerDiemCost = existingPerDiemCostOptional.get();

            if (existingPerDiemCost.getBillGenerate().getBillGenerateTableId() == billGenerateTableId) {
               existingPerDiemCost.setNumberOfDays(updatedPDC.getNumberOfDays());
              existingPerDiemCost.setTotalAmount(updatedPDC.getTotalAmount());
              existingPerDiemCost.setSAC(existingPerDiemCost.getBillGenerate().getSAC());
                existingPerDiemCost.setDescription(updatedPDC.getDescription());

                return perDiemCostRepository.save(existingPerDiemCost);
            } else {
                throw new IllegalArgumentException("billGenerateTableId does not match the existing record");
            }
        } else {
            throw new EntityNotFoundException("PerDiemCost not found");
        }
   }

//    public PerDiemCost updatePerDiemCost(int PDC, int billGenerateTableId, PerDiemCost updatedPDC) {
//        Optional<PerDiemCost> existingPerDiemCostOptional = perDiemCostRepository.findById(PDC);
//
//        if (existingPerDiemCostOptional.isPresent()) {
//            PerDiemCost existingPerDiemCost = existingPerDiemCostOptional.get();
//
//            if (existingPerDiemCost.getBillGenerate().getBillGenerateTableId() == billGenerateTableId) {
//                existingPerDiemCost.setNumberOfDays(updatedPDC.getNumberOfDays());
//
//                // Calculate the totalAmount based on numberOfDays and costPerDiem
//                int costPerDiem = existingPerDiemCost.getProjectEmployees().getProject().getCostPerDiem();
//                existingPerDiemCost.setTotalAmount(existingPerDiemCost.getNumberOfDays() * costPerDiem);
//
//                return perDiemCostRepository.save(existingPerDiemCost);
//            } else {
//                throw new IllegalArgumentException("billGenerateTableId does not match the existing record");
//            }
//        } else {
//            throw new EntityNotFoundException("PerDiemCost not found");
//        }
//    }



    public List<PerDiemCost> getAllPerDiemCostsByBillGenerateTableId(int billGenerateTableId) {
        return perDiemCostRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
    }


}
