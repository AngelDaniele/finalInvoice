package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.ProjectHeadCountService;
import com.demo.GenerateInvoiceFinal.Service.Designation2Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/designation2Controller")
public class Designation2Controller {


    @Autowired
    private Designation2Service designation2Service;

@Autowired
private ProjectHeadCountService designation1Service;

//    @PutMapping("/updateEmployee/{designation1Id}")
//    public ResponseEntity<List<Designation2>> updateEmployeeInDesignation2(
//            @PathVariable int designation1Id,
//            @RequestBody List<EmployeeInfoList> employeeUpdateInfos
//    ) {
//        List<Designation2> updatedDesignation2List = designation2Service.updateEmployeeInDesignation2(designation1Id, employeeUpdateInfos);
//        if (updatedDesignation2List != null) {
//            return ResponseEntity.ok(updatedDesignation2List);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }


//    @GetMapping("/byProject/{projectId}")
//    public List<Designation2> getDesignation2ListByProjectId(@PathVariable String projectId) {
//        return designation2Service.getDesignation2ListByProjectId(projectId);
//    }

//    @PutMapping("/{designation2Id}")
//    public ResponseEntity<Designation2> updateDesignation2(@PathVariable int designation2Id,
//                                                           @RequestBody UpdatedDesignation2 updatedDesignation2) {
//        Designation2 updatedEntity = designation2Service.updateDesignation2(designation2Id, updatedDesignation2);
//        return ResponseEntity.ok(updatedEntity);
//    }
}
