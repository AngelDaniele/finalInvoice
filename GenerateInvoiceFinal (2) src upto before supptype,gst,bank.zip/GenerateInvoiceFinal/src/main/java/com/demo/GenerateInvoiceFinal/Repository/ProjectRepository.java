package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProjectRepository extends JpaRepository<Project,Integer> {




        public Project findByProjectId(String projectId);
    Project findByProjectNameIgnoreCase(String projectName);

    Optional<Project> findByProjectTableId(int projectTableId);
}

