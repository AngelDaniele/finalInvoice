package com.demo.GenerateInvoiceFinal.Controller;


import com.demo.GenerateInvoiceFinal.Service.BillGenerateService;
import com.demo.GenerateInvoiceFinal.model.BGTable;
import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.BillGenerateUI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/billgenerate")
public class BillGenerateController {


    @Autowired
    private BillGenerateService billGenerateService;


    @PostMapping("/create/{userId}")
    public BillGenerate createBillGenerate(@RequestBody BillGenerateUI billGenerateUI, @PathVariable String userId ) {
        return billGenerateService.saveBillGenerate(billGenerateUI,userId);
    }


//   @PostMapping("/create")
//    public ResponseEntity<BillGenerate> createBillGenerate(@RequestBody BillGenerateUI billGenerateUI) {
//          BillGenerate savedBillGenerate = billGenerateService.saveBillGenerate(billGenerateUI);
//
//    }

    @GetMapping("/all")
    public ResponseEntity<List<BillGenerate>> getAllBillGenerates() {
        List<BillGenerate> billGenerates = billGenerateService.getAllBillGenerates();
        return ResponseEntity.ok(billGenerates);
    }

    @GetMapping("/{billGenerateTableId}/dates")
    public ResponseEntity<BillGenerate> getBillGenerateDates(@PathVariable int billGenerateTableId) {
        BillGenerate billGenerate = billGenerateService.getBillGenerateDatesById(billGenerateTableId);

        if (billGenerate != null) {
            return ResponseEntity.ok(billGenerate);
        } else {
            // Handle the case where the specified billGenerateTableId was not found
            return ResponseEntity.notFound().build();
        }
    }



    @GetMapping("/{projectId}")
    public ResponseEntity<List<BillGenerate>> getBillGenerateByProjectId(@PathVariable String projectId) {
        List<BillGenerate> billGenerateList = billGenerateService.getBillGenerateByProjectId(projectId);
        return ResponseEntity.ok(billGenerateList);
    }



}




