package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Exception.ClientNotFoundException;
import com.demo.GenerateInvoiceFinal.Exception.EmployeeNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.DesignationRepository;
import com.demo.GenerateInvoiceFinal.Repository.EmployeeRepository;
import com.demo.GenerateInvoiceFinal.model.Designation;
import com.demo.GenerateInvoiceFinal.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {



    @Autowired
    DesignationRepository  designationRepository;


        @Autowired
        EmployeeRepository employeeRepository;



    public Employee saveEmployee(Employee employee, String userId) {

        employee.setUserId(userId);
        employee.setTimeStamp(LocalDateTime.now());


        Employee savedEmployee = employeeRepository.save(employee);



        String designationName = employee.getDesignation();
        Designation existingDesignation = designationRepository.findByDesignationIgnoreCase(designationName);

        // If the designation doesn't exist, create a new one
        if (existingDesignation == null) {
            Designation newDesignation = new Designation();
            newDesignation.setDesignation(designationName);
            designationRepository.save(newDesignation);
        }
        return savedEmployee;
    }

        public List<Employee> getAllEmployee() {

            List<Employee> list = employeeRepository.findAll();

            if (list.size() > 0) {
                return list;
            } else
                throw new ClientNotFoundException("No Client in catalog");
        }

        public Employee updateEmployee(Employee employee, int key) throws EmployeeNotFoundException {
            Optional<Employee> optionalEmployee = employeeRepository.findById(key);

            if (optionalEmployee.isPresent()) {
                Employee existingEmployee = optionalEmployee.get();
                existingEmployee.setEmployeeId(employee.getEmployeeId());
                existingEmployee.setEmployeeName(employee.getEmployeeName());
                existingEmployee.setDesignation(employee.getDesignation());
                existingEmployee.setAddress(employee.getAddress());
                existingEmployee.setEducationalQualification(employee.getEducationalQualification());

                Employee updatedEmployee = employeeRepository.save(existingEmployee);
                return updatedEmployee;
            } else {
                throw new EmployeeNotFoundException("Employee not found with the given id");
            }
        }


        public String deleteEmployee(Integer id) throws EmployeeNotFoundException{

            Optional<Employee> opt=	employeeRepository.findById(id);

            if(opt.isPresent()) {
                Employee employee = opt.get();
                employeeRepository.delete(employee);
                return "Employee deleted";
            } else
                throw new EmployeeNotFoundException("Employee not found with given id");
        }


    }


