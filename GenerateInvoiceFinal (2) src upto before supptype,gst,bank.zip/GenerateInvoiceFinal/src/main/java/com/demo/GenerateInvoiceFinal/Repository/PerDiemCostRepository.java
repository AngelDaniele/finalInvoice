package com.demo.GenerateInvoiceFinal.Repository;


import com.demo.GenerateInvoiceFinal.model.PerDiemCost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface PerDiemCostRepository extends JpaRepository<PerDiemCost,Integer> {
//
//    @Query("SELECT p FROM PerDiemCost p WHERE p.billGenerate.billGenerateTableId = :billGenerateTableId")
//    List<PerDiemCost> findByBillGenerateTableId(@Param("billGenerateTableId") Integer billGenerateTableId);

    List<PerDiemCost> findAllByBillGenerate_BillGenerateTableId(int billGenerateTableId);


//    @Query("SELECT p FROM PerDiemCost p WHERE p.billGenerate.billGenerateTableId = :billGenerateTableId")
//    List<PerDiemCost> findUnionDataByBillGenerateTableId(@Param("billGenerateTableId") Integer billGenerateTableId);
//    Collection<?> findUnionDataByBillGenerateTableId(Integer billGenerateTableId);
}
