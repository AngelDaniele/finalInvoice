package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Exception.ClientNotFoundException;
import com.demo.GenerateInvoiceFinal.Exception.ProjectNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.ClientRepository;
import com.demo.GenerateInvoiceFinal.Repository.ProjectHeadCountRepository;
import com.demo.GenerateInvoiceFinal.Repository.ProjectRepository;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ProjectService {




        @Autowired
        ProjectRepository projectRepository;

        @Autowired
        ClientRepository clientRepository;
    @Autowired
    ProjectHeadCountRepository designation1Repository;


        public Project saveProjectWithClientId(ProjectWithClientIdRequest request, String clientId, String userId) {

            Client client = clientRepository.findByClientId(clientId);

            if (client == null) {
                throw new ClientNotFoundException("Client not found for clientId: " + clientId);
            }


            Project project = new Project();
            project.setProjectId(request.getProjectId());
            project.setProjectName(request.getProjectName());
            project.setStartDate(request.getStartDate());
            project.setEndDate(request.getEndDate());
            project.setBudget(request.getBudget());
//            project.setRemaindingBudget(0);
            project.setClient(client);
            project.setTimeStamp(LocalDateTime.now());
            project.setUserId(userId);

//           if (request.isCheckBox()) {
//                project.setCheckBox(true);
               project.setCostPerDiem(request.getCostPerDiem());
//         } else {
//               project.setCheckBox(false);
//
//          }


//            if (request.isTdm()) {
//                project.setTdm(true);
//            } else {
//                project.setTdm(false);
//            }

            project.setCurrency(request.getCurrency());


            return projectRepository.save(project);
        }



    public List<Project> getAllProject() {

            List<Project> list = projectRepository.findAll();

            if (list.size() > 0) {
                return list;
            } else
                throw new ProjectNotFoundException("No Project in catalog");
        }


        public Project findByProjectId( String projectId) {

            return projectRepository.findByProjectId(projectId);
        }




    public Project findProjectByNameIgnoreCase(String projectName) {
        return projectRepository.findByProjectNameIgnoreCase(projectName);
    }
    }













