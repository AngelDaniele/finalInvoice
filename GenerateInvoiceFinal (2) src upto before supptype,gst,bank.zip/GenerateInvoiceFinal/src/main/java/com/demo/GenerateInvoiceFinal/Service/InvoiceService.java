package com.demo.GenerateInvoiceFinal.Service;


import com.demo.GenerateInvoiceFinal.Repository.*;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class InvoiceService {


    @Autowired
    BillGenerateRepository billGenerateRepository;


    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private DesignationSummaryRepository designationSummaryRepository;

    @Autowired
    private BGTableRepository bgTableRepository;

    @Autowired
    ProjectEmployeeRepository projectEmployeesRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private DescriptionRepository descriptionRepository;

    @Autowired
    private InvoiceBillGenerateRepsoitory  invoiceBillGenerateRepository;

    @Autowired
    private FinalInvoiceVersionRepository finalInvoiceVersionRepository ;








    public Invoice getInvoiceByBillGenerateTableId(int billGenerateTableId) {

        return invoiceRepository.findByBillGenerateTableId(billGenerateTableId);
    }


    public Invoice createInvoice(int billGenerateTableId, String userId) {

        Optional<Invoice> existingInvoice = Optional.ofNullable(invoiceRepository.findByBillGenerateTableId(billGenerateTableId));

        if (existingInvoice.isPresent()) {
            // If an invoice already exists, you can handle it as needed.
            // For example, you can throw an exception, return the existing invoice, or take another action.
            // In this example, we're throwing an exception.

            return existingInvoice.get();

        }

        BillGenerate billGenerate = billGenerateRepository.findById(billGenerateTableId)
                .orElseThrow(() -> new IllegalArgumentException("BillGenerate not found"));


//        ProjectEmployees projectEmployees = billGenerate.getProjectEmployees();
        Project project = billGenerate.getProject();


//        int budget = project.getRemaindingBudget();

        List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
        BigDecimal subtotal = BigDecimal.ZERO;

        for (BGTable bgTable : bgTableEntries) {
            subtotal = subtotal.add(new BigDecimal(bgTable.getTotalAmount()));
        }


        BigDecimal cgstPercentage = new BigDecimal("9.00"); // 9% CGST
        BigDecimal sgstPercentage = new BigDecimal("9.00"); // 9% SGST

        BigDecimal cgst = subtotal.multiply(cgstPercentage.divide(new BigDecimal("100")));
        BigDecimal sgst = subtotal.multiply(sgstPercentage.divide(new BigDecimal("100")));


        BigDecimal totalAmount = subtotal.add(cgst).add(sgst);

        List<Description> descriptionEntries = descriptionRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
        BigDecimal totalCharges = BigDecimal.ZERO;

        for (Description description : descriptionEntries) {
            totalCharges = totalCharges.add(new BigDecimal(description.getAmount()));
        }

        BigDecimal grandTotal = totalAmount.add(totalCharges);


//
//        if (totalAmount.compareTo(new BigDecimal(budget)) > 0) {
//            throw new IllegalArgumentException("TotalAmount exceeds the project budget");
//        }

        // Create and save the Invoice
        Invoice invoice = new Invoice();
        invoice.setBillGenerateTableId(billGenerateTableId);
        invoice.setCgst(cgst);
        invoice.setSgst(sgst);
        invoice.setSubtotal(subtotal);
        invoice.setTotalAmount(totalAmount);
        invoice.setTotalCharges(totalCharges);
        invoice.setGrandTotal(grandTotal);
        invoice.setUserId(userId);

        // Set the current date and time
        invoice.setTimeStamp(LocalDateTime.now());
        invoice.setRFM(false);
        invoice.setStatus("ACTIVE");
        invoiceRepository.save(invoice);






        if (!invoice.isRFM()) { // Only create FinalInvoiceVersion if RFM is false
            // Create and save the FinalInvoiceVersion
            FinalInvoiceVersion finalInvoiceVersion = new FinalInvoiceVersion();
            finalInvoiceVersion.setInvoice(invoice); // Link to the created Invoice
            finalInvoiceVersion.setRFM(false); // Set RFM to false
            finalInvoiceVersion.setStatus("ACTIVE"); // Set status to "ACTIVE"
            finalInvoiceVersion.setVersionNo(0); // Set version number to 0

            // Link to the same billGenerateTable
            finalInvoiceVersion.setBillGenerate(billGenerate);

            // Set other properties to 0 or null
            finalInvoiceVersion.setEditDesignationSummary(null);
            finalInvoiceVersion.setEditDescription(null);
            finalInvoiceVersion.setEditPerDiemCost(null);

            // Save the FinalInvoiceVersion
            finalInvoiceVersionRepository.save(finalInvoiceVersion);

            InvoiceBillGenerate invoiceBillGenerate = new InvoiceBillGenerate();
            invoiceBillGenerate.setBillGenerate(billGenerate);
            invoiceBillGenerate.setInvoice(invoice);
            invoiceBillGenerate.setProject(billGenerate.getProject());
            invoiceBillGenerate.setVersionNo(finalInvoiceVersion.getVersionNo());
            invoiceBillGenerateRepository.save(invoiceBillGenerate);
        }

        return invoice;
    }





}









