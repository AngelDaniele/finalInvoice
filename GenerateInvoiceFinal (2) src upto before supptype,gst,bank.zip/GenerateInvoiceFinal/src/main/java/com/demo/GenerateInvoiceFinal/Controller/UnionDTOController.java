package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.UnionDTOService;
import com.demo.GenerateInvoiceFinal.model.UnionDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/Union")
public class UnionDTOController {

    @Autowired
    private UnionDTOService unionDTOService;


    @GetMapping("/{billGenerateTableId}")
    public List<UnionDTO> getUnionDTOs(@PathVariable int billGenerateTableId) {
        return unionDTOService.getUnionDTOsByBillGenerateTableId(billGenerateTableId);
    }
}
