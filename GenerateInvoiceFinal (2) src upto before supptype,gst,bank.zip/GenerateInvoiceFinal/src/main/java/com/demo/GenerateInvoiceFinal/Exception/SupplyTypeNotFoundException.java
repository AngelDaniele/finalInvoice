package com.demo.GenerateInvoiceFinal.Exception;

public class SupplyTypeNotFoundException extends RuntimeException{


    public SupplyTypeNotFoundException(String message){
        super(message);
    }
}
