package com.demo.GenerateInvoiceFinal.model;

import java.util.List;

public class SearchResponseDTO {

    private Project project;
    private List<BillGenerate> billGenerates;
    private List<Invoice> invoices;

    public SearchResponseDTO(Project project, List<BillGenerate> billGenerates, List<Invoice> invoices) {
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public List<BillGenerate> getBillGenerates() {
        return billGenerates;
    }

    public void setBillGenerates(List<BillGenerate> billGenerates) {
        this.billGenerates = billGenerates;
    }

    public List<Invoice> getInvoices() {
        return invoices;
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }
}
