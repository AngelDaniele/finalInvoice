package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.BillGenerateRepository;
import com.demo.GenerateInvoiceFinal.Repository.DescriptionRepository;
import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.Description;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class DescriptionService {

    @Autowired
    private BillGenerateService billGenerateService;

    @Autowired
DescriptionRepository descriptionRepository;


    @Autowired
    BillGenerateRepository billGenerateRepository;

    public List<Description> saveDescriptionsWithBillGenerate(Object requestBody, Integer billGenerateTableId) {
        List<Description> savedDescriptions = new ArrayList<>();


        if (requestBody instanceof List) {
            // If the request body is a list, process each Description object
            List<Object> requestList = (List<Object>) requestBody;
            for (Object obj : requestList) {
                if (obj instanceof Map) {
                    Map<String, Object> descriptionMap = (Map<String, Object>) obj;

                    // Extract the date as a string
                    String dateStr = (String) descriptionMap.get("date");

                    // Convert the date string to LocalDate
                    LocalDate date = LocalDate.parse(dateStr);

                    // Remove the date from the map
                    descriptionMap.remove("date");

                    // Convert the Map to a Description object
                    ObjectMapper objectMapper = new ObjectMapper();
                    Description description = objectMapper.convertValue(descriptionMap, Description.class);
                    description.setBillGenerateTableId(billGenerateTableId);
//                   BillGenerate billGenerate = billGenerateService.getBillGenerateById(billGenerateTableId);
//                   description.setSAC(billGenerate.getSAC());


                    description.setDate(date); // Set the date

                    // Save the Description object
                    Description savedDescription = saveDescription(description);
                    savedDescriptions.add(savedDescription);
                }
            }
        } else if (requestBody instanceof Map) {
            // If the request body is a single Description object, convert it and save it
            ObjectMapper objectMapper = new ObjectMapper();
            Description description = objectMapper.convertValue(requestBody, Description.class);
            description.setBillGenerateTableId(billGenerateTableId);


            // Save the Description object
            Description savedDescription = saveDescription(description);
            savedDescriptions.add(savedDescription);
        }

        return savedDescriptions;
    }
    public Description saveDescription(Description description) {
        // Fetch the associated BillGenerate object
        BillGenerate billGenerate = billGenerateService.getBillGenerateById(description.getBillGenerateTableId());

        // Check if the fetched BillGenerate is not null before accessing its properties
        if (billGenerate != null) {
            // Set the SAC field in the Description object
            description.setSAC(billGenerate.getSAC());

            // Set the BillGenerate reference in the Description object
            description.setBillGenerate(billGenerate);

            // Save the Description object
            return descriptionRepository.save(description);
        } else {
            // Handle the case where BillGenerate is not found
            // You might want to log a message or throw an exception
            return null;
        }
    }


//    public Description saveDescription(Description description) {
//        // Check if a Description with the same value and billGenerateTableId already exists
//        boolean exists = descriptionRepository.customExistsByDescriptionAndBillGenerate_IdAndDate(
//                description.getDescription(), description.getBillGenerateTableId(),description.getDate());
//
//        if (!exists) {
//            // If it does not exist, proceed with saving
//            BillGenerate billGenerate = new BillGenerate();
//            billGenerate.setBillGenerateTableId(description.getBillGenerateTableId());
//            description.setBillGenerate(billGenerate);
////            description.setSAC(description.getSAC());
//            return descriptionRepository.save(description);
//        } else {
//            // If it exists, you may handle this case as needed (e.g., throw an exception, log a message, etc.)
//            // For now, returning null, but you can adjust this based on your requirements
//            return null;
//        }
//    }



//    public Description saveDescription(Description description) {
//        BillGenerate billGenerate = new BillGenerate();
//        billGenerate.setBillGenerateTableId(description.getBillGenerateTableId());
//        description.setBillGenerate(billGenerate);
//        return descriptionRepository.save(description);
//    }


    public List<Description> getAllDescriptions() {
        return descriptionRepository.findAll();
    }



    public List<Description> getDescriptionsByBillGenerateTableId(Integer billGenerateTableId) {
        return descriptionRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
    }
        // Add descriptionRepository and other dependencies as needed
    }










