package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.SubProject;
import com.demo.GenerateInvoiceFinal.model.SupplyType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SupplyTypeRepository extends JpaRepository<SupplyType,Integer> {


}
