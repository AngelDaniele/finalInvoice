package com.demo.GenerateInvoiceFinal.Repository;


import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface BillGenerateRepository extends JpaRepository<BillGenerate,Integer> {
    List<BillGenerate> findByProject_ProjectId(String projectId);

    BillGenerate findByBillGenerateTableId(Integer billGenerateTableId);
//    boolean existsByDescriptionAndBillGenerateTableId(String description, Integer billGenerateTableId);

}
