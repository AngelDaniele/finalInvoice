package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.BGTableRepository;
import com.demo.GenerateInvoiceFinal.Repository.CompanyRepository;
import com.demo.GenerateInvoiceFinal.model.BGTable;
import com.demo.GenerateInvoiceFinal.model.Company;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CompanyService {

    @Autowired
    private CompanyRepository companyRepository;

//    public List<Company> getCompany() {
//        return companyRepositoryRepository.findAll();
//    }

    public Optional<Company> getCompanyById(int companyTableId) {
        return companyRepository.findById(companyTableId);
    }



}
