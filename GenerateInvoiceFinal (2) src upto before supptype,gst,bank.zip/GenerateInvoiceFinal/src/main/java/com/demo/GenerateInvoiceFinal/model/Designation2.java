package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "Designation2")
public class Designation2 {


        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "designation2Id")
        private int designation2Id;



    @ManyToOne
    @JoinColumn(name = "employeeTableId")
    private Employee employee;





        @Column(name = "designation", length = 300)
        private String designation;

    @Column(name = "onsiteOrOffsite")
    private String onsiteOrOffsite;

        @Column(name = "rate")
        private int rate;

        @Column(name = "location", length = 300)
        private String location;


    @Column(name = "startDate")
    private LocalDate startDate;

    @Column(name = "endDate")
    private LocalDate endDate;


    public int getDesignation2Id() {
        return designation2Id;
    }

    public void setDesignation2Id(int designation2Id) {
        this.designation2Id = designation2Id;
    }

//    public Project getProject() {
//        return project;
//    }
//
//    public void setProject(Project project) {
//        this.project = project;
//    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }



    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getOnsiteOrOffsite() {
        return onsiteOrOffsite;
    }

    public void setOnsiteOrOffsite(String onsiteOrOffsite) {
        this.onsiteOrOffsite = onsiteOrOffsite;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;


    }



    //    public ProjectEmployees getProjectEmployees() {
//        return projectEmployees;
//    }
//
//    public void setProjectEmployees(ProjectEmployees projectEmployees) {
//        this.projectEmployees = projectEmployees;
//    }



//    public Designation1 getDesignation1() {
//        return designation1;
//    }
//
//    public void setDesignation1(Designation1 designation1) {
//        this.designation1 = designation1;
//    }
}




