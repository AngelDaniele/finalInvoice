package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.Designation2Repository;
import com.demo.GenerateInvoiceFinal.Repository.EmployeeRepository;
import com.demo.GenerateInvoiceFinal.Repository.ProjectEmployeeRepository;
import com.demo.GenerateInvoiceFinal.Repository.ProjectRepository;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class Designation2Service {


    @Autowired
    Designation2Repository designation2Repository;

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    ProjectRepository projectRepository;
    @Autowired
    ProjectEmployeeRepository projectEmployeeRepository;




//    public List<Designation2> updateEmployeeInDesignation2(int designation1Id, List<String> employeeIds) {
//        List<Designation2> designation2List = designation2Repository.findByDesignation1Designation1Id(designation1Id);
//
//        for (int i = 0; i < Math.min(designation2List.size(), employeeIds.size()); i++) {
//            Designation2 designation2 = designation2List.get(i);
//            String employeeId = employeeIds.get(i);
//            Employee employee = employeeRepository.findByEmployeeId(employeeId);
//
//            if (employee != null) {
//                // Update the employee in the Designation2 table
//                designation2.setEmployee(employee);
//
//                // Now, set the project from the designation2 object
//                Project project = designation2.getProject(); // Assuming you have this relationship mapped in the Designation2 entity
//                ProjectEmployees projectEmployee = new ProjectEmployees();
//                projectEmployee.setEmployee(employee);
//                projectEmployee.setProject(project);
//                projectEmployee.setUserId(project.getUserId()); // You may need to set the userId based on your logic
//                projectEmployee.setTimeStamp(LocalDateTime.now()); // Set the timestamp as needed
//                projectEmployeeRepository.save(projectEmployee); // You need to have a projectEmployee repository
//                designation2.setProjectEmployees(projectEmployee);
//                designation2Repository.save(designation2);
//            }
//        }
//
//        return designation2List;
//    }
//




//    public List<Designation2> updateEmployeeInDesignation2(int designation1Id, List<EmployeeInfoList> employeeUpdateInfos) {
//        List<Designation2> designation2List = designation2Repository.findByDesignation1Designation1Id(designation1Id);
//
//        for (int i = 0; i < Math.min(designation2List.size(), employeeUpdateInfos.size()); i++) {
//            Designation2 designation2 = designation2List.get(i);
//            EmployeeInfoList employeeUpdateInfo = employeeUpdateInfos.get(i);
//
//            String employeeId = employeeUpdateInfo.getEmployeeId();
//            LocalDate startDate = employeeUpdateInfo.getStartDate();
//            LocalDate endDate = employeeUpdateInfo.getEndDate();
//
//            Employee employee = employeeRepository.findByEmployeeId(employeeId);
//
//            if (employee != null) {
//                // Update the employee in the Designation2 table
//                designation2.setEmployee(employee);
//                designation2.setStartDate(startDate);
//                designation2.setEndDate(endDate);
//
//
//                Project project = designation2.getProject();
//                ProjectEmployees projectEmployee = new ProjectEmployees();
//                projectEmployee.setEmployee(employee);
//                projectEmployee.setProject(project);
//                projectEmployee.setUserId(project.getUserId()); // You may need to set the userId based on your logic
//                projectEmployee.setTimeStamp(LocalDateTime.now()); // Set the timestamp as needed
//
//                projectEmployeeRepository.save(projectEmployee); // You need to have a projectEmployee repository
//                designation2.setProjectEmployees(projectEmployee);
//                designation2Repository.save(designation2);
//            }
//        }
//
//        return designation2List;
//    }

//
//    public List<Designation2> getDesignation2ListByProjectId(String projectId) {
//        return designation2Repository.findByProjectId(projectId);
//    }

    public Designation2 updateDesignation2(int designation2Id, UpdatedDesignation2 updatedDesignation2) {
        Designation2 existingDesignation2 = designation2Repository.findById(designation2Id)
                .orElseThrow(() -> new EntityNotFoundException("Designation2 not found with id: " + designation2Id));

        // Update only the specified fields
        if (updatedDesignation2.getEmployeeId() != null) {
            Employee employee = employeeRepository.findByEmployeeId(updatedDesignation2.getEmployeeId());
            existingDesignation2.setEmployee(employee);
        }

        if (updatedDesignation2.getStartDate() != null) {
            existingDesignation2.setStartDate(updatedDesignation2.getStartDate());
        }

        if (updatedDesignation2.getEndDate() != null) {
            existingDesignation2.setEndDate(updatedDesignation2.getEndDate());
        }

        // Update other fields if needed...

        return designation2Repository.save(existingDesignation2);
    }

}
