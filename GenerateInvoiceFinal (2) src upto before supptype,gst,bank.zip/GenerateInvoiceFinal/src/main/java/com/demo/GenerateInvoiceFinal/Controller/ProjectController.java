package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Repository.BillGenerateRepository;
import com.demo.GenerateInvoiceFinal.Repository.InvoiceRepository;
import com.demo.GenerateInvoiceFinal.Service.ProjectService;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/project")
public class ProjectController {


        @Autowired
        ProjectService projectService;

        @Autowired
    BillGenerateRepository billGenerateRepository;

        @Autowired
    InvoiceRepository invoiceRepository;

        @PostMapping("/saveproject/{userId}")
        public ResponseEntity<Project> createProjectWithClientId(
                @RequestBody ProjectWithClientIdRequest request, @PathVariable String userId) {
            String clientId = request.getClientId();
            Project savedProject = projectService.saveProjectWithClientId(request, clientId,userId);
            return new ResponseEntity<>(savedProject, HttpStatus.CREATED);
        }

        @GetMapping("/allproject")
        public List<Project> getAllproject(){

            return projectService.getAllProject();
        }
        @GetMapping("/{projectId}")
         public Project getProjectById(@PathVariable String projectId){

            return projectService.findByProjectId(projectId);
        }





    }


