package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "FinalInvoiceVersion")
public class FinalInvoiceVersion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "invoiceId")
    private int invoiceId;

    @ManyToOne
    @JoinColumn(name = "invoiceNumber")
    private Invoice invoice;

    @Column(name = "RFM")
    private boolean RFM;

    @Column(name = "status")
    private String status;

    @Column(name = "versionNo")
    private int versionNo;

    @ManyToOne
    @JoinColumn(name = "billGenerateTableId")
    private BillGenerate billGenerate;

    @ManyToOne
    @JoinColumn(name = "EditDesignationSummaryId")
    private EditDesignationSummary editDesignationSummary;

    @ManyToOne
    @JoinColumn(name = "EditDescriptionid")
    private EditDescription editDescription;

    @ManyToOne
    @JoinColumn(name = "PDC")
    private EditPerDiemCost editPerDiemCost;

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public boolean isRFM() {
        return RFM;
    }

    public void setRFM(boolean RFM) {
        this.RFM = RFM;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(int versionNo) {
        this.versionNo = versionNo;
    }

    public BillGenerate getBillGenerate() {
        return billGenerate;
    }

    public void setBillGenerate(BillGenerate billGenerate) {
        this.billGenerate = billGenerate;
    }

    public EditDesignationSummary getEditDesignationSummary() {
        return editDesignationSummary;
    }

    public void setEditDesignationSummary(EditDesignationSummary editDesignationSummary) {
        this.editDesignationSummary = editDesignationSummary;
    }

    public EditDescription getEditDescription() {
        return editDescription;
    }

    public void setEditDescription(EditDescription editDescription) {
        this.editDescription = editDescription;
    }

    public EditPerDiemCost getEditPerDiemCost() {
        return editPerDiemCost;
    }

    public void setEditPerDiemCost(EditPerDiemCost editPerDiemCost) {
        this.editPerDiemCost = editPerDiemCost;
    }
}
