package com.demo.GenerateInvoiceFinal.Controller;

;
import com.demo.GenerateInvoiceFinal.Repository.InvoiceRepository;
import com.demo.GenerateInvoiceFinal.Service.InvoiceService;
import com.demo.GenerateInvoiceFinal.model.Invoice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/invoices")
public class InvoiceController {

      @Autowired
        InvoiceRepository invoiceRepository;

        @Autowired
        private InvoiceService invoiceService;

        @PostMapping("/generate/{billGenerateTableId}/{userId}")
        public ResponseEntity<Object> generateInvoice(@PathVariable int billGenerateTableId,@PathVariable String userId) {

                Invoice invoice = invoiceService.createInvoice(billGenerateTableId,userId);
                return new ResponseEntity<>(invoice, HttpStatus.CREATED);

        }

        @GetMapping("/retrieve/{billGenerateTableId}")
        public ResponseEntity<Object> retrieveInvoice(@PathVariable int billGenerateTableId) {
                Invoice invoice = invoiceService.getInvoiceByBillGenerateTableId(billGenerateTableId);

                if (invoice != null) {
                        return new ResponseEntity<>(invoice, HttpStatus.OK);
                } else {
                        return new ResponseEntity<>("Invoice not found", HttpStatus.NOT_FOUND);
                }




        }









}






