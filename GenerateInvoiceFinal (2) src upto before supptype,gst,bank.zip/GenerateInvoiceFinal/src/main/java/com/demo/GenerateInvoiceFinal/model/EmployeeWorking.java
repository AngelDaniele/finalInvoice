package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "EmployeeWorking")
public class EmployeeWorking {



        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "employeeWorkingTableId")
        private int employeeWorkingTableId;



        @Column(name = "Date")
        private LocalDate date;



        @ManyToOne
        @JoinColumn(name = "projectEmployeeId")
        private ProjectEmployees projectEmployees;



        public EmployeeWorking() {

        }

        public EmployeeWorking( LocalDate date) {

            this.date = date;

        }

    public EmployeeWorking(LocalDate randomDate, String pending) {
    }

    // Getters and setters

        public int getEmployeeWorkingTableId() {
            return employeeWorkingTableId;
        }

        public void setEmployeeWorkingTableId(int employeeWorkingTableId) {
            this.employeeWorkingTableId = employeeWorkingTableId;
        }


    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }



        public ProjectEmployees getProjectEmployees() {
            return projectEmployees;
        }

        public void setProjectEmployees(ProjectEmployees projectEmployees) {
            this.projectEmployees = projectEmployees;
        }
    }




