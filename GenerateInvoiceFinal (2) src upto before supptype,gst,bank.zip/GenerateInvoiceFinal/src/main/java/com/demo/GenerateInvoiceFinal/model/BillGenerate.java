package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "BillGenerate")
public class BillGenerate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "billGenerateTableId")
    private int billGenerateTableId;

    @ManyToOne
    @JoinColumn(name = "projectTableId")
    private Project project;





    @Column(name = "billGenerateStartDate")
    private LocalDate billGenerateStartDate;

    @Column(name = "billGenerateEndDate")
    private LocalDate billGenerateEndDate;



    @Column(name = "billGenerateAmount")
    private int billGenerateAmount;

    @Column(name="userId")
    private String userId;

    @Column(name="timeStamp")
    private LocalDateTime timeStamp;

    @Column(name="SAC")
    private int  SAC;




    //    @Column(name = "remaindingBudget")
//    private int remaindingBudget;


    public BillGenerate() {
    }

    public int getBillGenerateTableId() {
        return billGenerateTableId;
    }

    public void setBillGenerateTableId(int billGenerateTableId) {
        this.billGenerateTableId = billGenerateTableId;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }




//    public ProjectEmployees getProjectEmployees() {
//        return projectEmployees;
//    }
//
//    public void setProjectEmployees(ProjectEmployees projectEmployees) {
//        this.projectEmployees = projectEmployees;
//    }

    public LocalDate getBillGenerateStartDate() {
        return billGenerateStartDate;
    }

    public void setBillGenerateStartDate(LocalDate billGenerateStartDate) {
        this.billGenerateStartDate = billGenerateStartDate;
    }

    public LocalDate getBillGenerateEndDate() {
        return billGenerateEndDate;
    }

    public void setBillGenerateEndDate(LocalDate billGenerateEndDate) {
        this.billGenerateEndDate = billGenerateEndDate;
    }

//    public int getRemaindingBudget() {
//        return remaindingBudget;
//    }
//
//    public void setRemaindingBudget(int remaindingBudget) {
//        this.remaindingBudget = remaindingBudget;
//    }

    public int getBillGenerateAmount() {
        return billGenerateAmount;
    }

    public void setBillGenerateAmount(int billGenerateAmount) {
        this.billGenerateAmount = billGenerateAmount;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }


    public int getSAC() {
        return SAC;
    }

    public void setSAC(int SAC) {
        this.SAC = SAC;
    }


}




