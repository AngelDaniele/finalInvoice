package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.InvoiceBillGenerateService;
import com.demo.GenerateInvoiceFinal.model.Invoice;
import com.demo.GenerateInvoiceFinal.model.InvoiceBillGenerate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/InvoiceBillGenerate")
public class InvoiceBillGenerateController {

    @Autowired
    InvoiceBillGenerateService invoiceBillGenerateService;



    @GetMapping("/{projectName}")
    public ResponseEntity<List<InvoiceBillGenerate>> getDetailsByProjectName(@PathVariable String projectName) {
        List<InvoiceBillGenerate> details = invoiceBillGenerateService.getDetailsByProjectName(projectName);
        return ResponseEntity.ok(details);
    }


    @GetMapping("/client/{clientName}")
    public ResponseEntity<List<InvoiceBillGenerate>> getDetailsByClientName(@PathVariable String clientName) {
        List<InvoiceBillGenerate> details = invoiceBillGenerateService.getDetailsByClientName(clientName);
        return ResponseEntity.ok(details);
    }







//    @GetMapping("/find/{date}")
//    public ResponseEntity<List<InvoiceBillGenerate>> findInvoiceByDate(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
//        List<InvoiceBillGenerate> invoiceBillGenerates = invoiceBillGenerateService.findInvoicesByDate(date);
//        if (!invoiceBillGenerates.isEmpty()) {
//            return new ResponseEntity<>(invoiceBillGenerates, HttpStatus.OK);
//        } else {
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//    }


}
