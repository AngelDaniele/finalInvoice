package com.demo.GenerateInvoiceFinal.Repository;

import com.demo.GenerateInvoiceFinal.model.EmployeeWorking;
import com.demo.GenerateInvoiceFinal.model.ProjectEmployees;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface EmployeeWorkingRepository extends JpaRepository<EmployeeWorking,Integer> {
    List<EmployeeWorking> findByProjectEmployeesAndDateBetween(
            ProjectEmployees projectEmployees, LocalDate startDate, LocalDate endDate);
}
