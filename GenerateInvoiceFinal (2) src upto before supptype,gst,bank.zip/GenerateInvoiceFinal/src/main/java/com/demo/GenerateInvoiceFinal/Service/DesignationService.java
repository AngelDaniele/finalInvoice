package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.DesignationRepository;
import com.demo.GenerateInvoiceFinal.model.Designation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DesignationService {

    @Autowired
    DesignationRepository designationRepository;

    public List<Designation> getAllDesignations() {
        return designationRepository.findAll();
    }

}
