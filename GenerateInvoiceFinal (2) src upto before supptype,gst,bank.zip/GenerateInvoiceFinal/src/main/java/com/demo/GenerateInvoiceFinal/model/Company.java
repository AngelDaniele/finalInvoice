package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name="Company")
public class Company {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="companyTableId")
    private  int companyTableId;

    private String companyName;
    private String companyAddress;
    private String primaryContactNumber;
    private String alternativeContactNumber;
    private String primaryMailId;
    private String alternativeMailId;
    private String gstRegisterationNumber;

    // Constructors, getters, and setters

    public Company() {
        // Default constructor
    }

    public int getCompanyTableId() {
        return companyTableId;
    }

    public void setCompanyTableId(int companyTableId) {
        this.companyTableId = companyTableId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getPrimaryContactNumber() {
        return primaryContactNumber;
    }

    public void setPrimaryContactNumber(String primaryContactNumber) {
        this.primaryContactNumber = primaryContactNumber;
    }

    public String getAlternativeContactNumber() {
        return alternativeContactNumber;
    }

    public void setAlternativeContactNumber(String alternativeContactNumber) {
        this.alternativeContactNumber = alternativeContactNumber;
    }

    public String getPrimaryMailId() {
        return primaryMailId;
    }

    public void setPrimaryMailId(String primaryMailId) {
        this.primaryMailId = primaryMailId;
    }

    public String getAlternativeMailId() {
        return alternativeMailId;
    }

    public void setAlternativeMailId(String alternativeMailId) {
        this.alternativeMailId = alternativeMailId;
    }

    public String getGstRegisterationNumber() {
        return gstRegisterationNumber;
    }

    public void setGstRegisterationNumber(String gstRegisterationNumber) {
        this.gstRegisterationNumber = gstRegisterationNumber;
    }
}
