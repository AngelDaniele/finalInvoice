package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name = "InvoiceBillGenerate")
public class InvoiceBillGenerate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "billGenerateTableId")
    private BillGenerate billGenerate;

    @ManyToOne
    @JoinColumn(name = "invoiceNumber")
    private Invoice invoice;

    @ManyToOne
    @JoinColumn(name = "projectTableId")
    private Project project;

    @Transient // This annotation tells JPA not to persist this property to the database
    private Integer billGenerateTableId;

    @Transient // This annotation tells JPA not to persist this property to the database
    private Integer invoiceNumber;

    @Column(name = "versionNo")
    private int versionNo;

    // Constructors, getters, and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BillGenerate getBillGenerate() {
        return billGenerate;
    }

    public void setBillGenerate(BillGenerate billGenerate) {
        this.billGenerate = billGenerate;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public Integer getBillGenerateTableId() {
        return billGenerateTableId;
    }

    public void setBillGenerateTableId(Integer billGenerateTableId) {
        this.billGenerateTableId = billGenerateTableId;
    }

    public Integer getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(Integer invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public int getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(int versionNo) {
        this.versionNo = versionNo;
    }
}
