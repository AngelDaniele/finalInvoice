package com.demo.GenerateInvoiceFinal.Service;


import com.demo.GenerateInvoiceFinal.Exception.ProjectNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.BGTableRepository;
import com.demo.GenerateInvoiceFinal.Repository.BillGenerateRepository;
import com.demo.GenerateInvoiceFinal.Repository.ProjectEmployeeRepository;
import com.demo.GenerateInvoiceFinal.model.BGTable;
import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class BGTableService {


        @Autowired
        private BGTableRepository bgTableRepository;

        @Autowired
        private BillGenerateRepository billGenerateRepository;

        @Autowired
        private ProjectEmployeeRepository projectEmployeeRepository;

    public BGTable updateBGTable(int bgTableId, int billGenerateTableId, BGTable updatedBGTable) {
        System.out.println("******************************************************************************************************************************");
        Optional<BGTable> existingBGTableOptional = bgTableRepository.findById(bgTableId);
        System.out.println("******************************************************************************************************************************");
        if (existingBGTableOptional.isPresent()) {
            BGTable existingBGTable = existingBGTableOptional.get();
            System.out.println("******************************************************************************************************************************");

            if (existingBGTable.getBillGenerate().getBillGenerateTableId() == billGenerateTableId) {
                System.out.println("******************************************************************************************************************************");
//                existingBGTable.setEmployeeWorkingStartDate(updatedBGTable.getEmployeeWorkingStartDate());
//                existingBGTable.setEmployeeWorkingEndDate(updatedBGTable.getEmployeeWorkingEndDate());
                existingBGTable.setTotalDays(updatedBGTable.getTotalDays());
                existingBGTable.setRate(updatedBGTable.getRate());
                existingBGTable.setTotalAmount(updatedBGTable.getTotalAmount());
               existingBGTable.setDescription(updatedBGTable.getDescription());
                System.out.println("******************************************************************************************************************************");

                System.out.println("Received Description: " + updatedBGTable.getDescription());
                return bgTableRepository.save(existingBGTable);


            } else {
                throw new IllegalArgumentException("billGenerateTableId does not match the existing record");
            }
        } else {
            throw new EntityNotFoundException("BGTable not found");
        }
    }




    private BillGenerate getBillGenerate(int billGenerateTableId) {

        Optional<BillGenerate> optionalBillGenerate = billGenerateRepository.findById(billGenerateTableId);

        if (optionalBillGenerate.isPresent()) {
            return optionalBillGenerate.get();
        } else {
            return null;
        }
    }


    public List<BGTable> getAllBGTable() {
        return bgTableRepository.findAll();
    }


    public List<BGTable> getAllBGTablesByBillGenerateTableId(int billGenerateTableId) {
        return bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
    }

    public BGTable updateBGTable(Integer bgTableId, BGTable updatedBGTable) {
        BGTable existingBGTable = bgTableRepository.findById(bgTableId)
                .orElseThrow(() -> new ProjectNotFoundException("BGTable not found with id: " + bgTableId));

        // Update fields based on your requirements
        existingBGTable.setTotalDays(updatedBGTable.getTotalDays());
        existingBGTable.setTotalAmount(updatedBGTable.getTotalAmount());
        existingBGTable.setDescription(updatedBGTable.getDescription());

        // Save the updated entity
        return bgTableRepository.save(existingBGTable);
    }

        }


