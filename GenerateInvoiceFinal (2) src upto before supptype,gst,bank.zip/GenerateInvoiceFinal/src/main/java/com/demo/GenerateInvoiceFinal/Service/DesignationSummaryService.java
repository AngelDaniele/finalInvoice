package com.demo.GenerateInvoiceFinal.Service;


import com.demo.GenerateInvoiceFinal.Repository.BGTableRepository;
import com.demo.GenerateInvoiceFinal.Repository.DesignationSummaryRepository;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class DesignationSummaryService {


    @Autowired
    private BGTableRepository bgTableRepository;
    @Autowired
    private DesignationSummaryRepository designationSummaryRepository;


    public List<DesignationSummary> calculateAndSaveDesignationSummary(int billGenerateTableId) {
        List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);

        Map<String, DesignationSummary> designationSummaryMap = new HashMap<>();

        // Fetch existing DesignationSummary records that match the billGenerateTableId
        List<DesignationSummary> existingDesignationSummaries = designationSummaryRepository.findByBillGenerateTableId(billGenerateTableId);

        for (BGTable bgTableEntry : bgTableEntries) {
            ProjectEmployees projectEmployees = bgTableEntry.getProjectEmployees();
            ProjectHeadCount projectHeadCount = projectEmployees.getProjectHeadCount();
            Designation designation = projectHeadCount.getDesignation();
            int rate = bgTableEntry.getRate();
            int totalAmount = bgTableEntry.getTotalAmount();

            boolean entryExists = false;

            for (DesignationSummary existingSummary : existingDesignationSummaries) {
                // Check if a matching entry already exists
                String existingDesignation = existingSummary.getDesignation();

                if (existingDesignation.equalsIgnoreCase(designation.getDesignation())) {
                    entryExists = true;
                    break;
                }
            }

            if (!entryExists) {
                if (designationSummaryMap.containsKey(designation.getDesignation())) {
                    DesignationSummary existingSummary = designationSummaryMap.get(designation.getDesignation());
                    existingSummary.setNumberOfEmployees(existingSummary.getNumberOfEmployees() + 1);
                    existingSummary.setTotalRate(existingSummary.getTotalRate() + rate);
                    existingSummary.setTotalAmount(existingSummary.getTotalAmount() + totalAmount);
                } else {
                    DesignationSummary newSummary = new DesignationSummary();
                    newSummary.setBillGenerateTableId(billGenerateTableId);
                    newSummary.setDesignation(designation.getDesignation());
                    newSummary.setNumberOfEmployees(1);
                    newSummary.setTotalRate(rate);
                    newSummary.setTotalAmount(totalAmount);
                    designationSummaryMap.put(designation.getDesignation(), newSummary);
                }
            }
        }

        List<DesignationSummary> savedDesignationSummaries = designationSummaryRepository.saveAll(designationSummaryMap.values());

        return savedDesignationSummaries;
    }


    public List<DesignationSummary> getDesignationSummariesByBillGenerateTableId(int billGenerateTableId) {
        return designationSummaryRepository.findByBillGenerateTableId(billGenerateTableId);
    }

//    public List<DesignationSummary> calculateAndSaveDesignationSummary(int billGenerateTableId) {
//        List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
//
//        Map<String, DesignationSummary> designationSummaryMap = new HashMap<>();
//
//        // Fetch existing DesignationSummary records that match the billGenerateTableId
//        List<DesignationSummary> existingDesignationSummaries = designationSummaryRepository.findByBillGenerateTableId(billGenerateTableId);
//
//        for (BGTable bgTableEntry : bgTableEntries) {
//            ProjectEmployees projectEmployees = bgTableEntry.getProjectEmployees();
//            Employee employee = projectEmployees.getEmployee();
//            String designation = employee.getDesignation();
//            int rate = bgTableEntry.getRate();
//            int totalAmount = bgTableEntry.getTotalAmount();
//
//            boolean entryExists = false;
//
//            for (DesignationSummary existingSummary : existingDesignationSummaries) {
//                // Check if a matching entry already exists
//                String existingDesignation = existingSummary.getDesignation();
//
//                if (existingSummary.getDesignation().equalsIgnoreCase(designation)) {
//                    entryExists = true;
//                    break;
//                }
//                System.out.println("Existing Designation: " + existingDesignation);
//                System.out.println("New Designation: " + designation);
//            }
//
//            if (!entryExists) {
//                if (designationSummaryMap.containsKey(designation)) {
//                    DesignationSummary existingSummary = designationSummaryMap.get(designation);
//                    existingSummary.setNumberOfEmployees(existingSummary.getNumberOfEmployees() + 1);
//                    existingSummary.setTotalRate(existingSummary.getTotalRate() + rate);
//                    existingSummary.setTotalAmount(existingSummary.getTotalAmount() + totalAmount);
//                } else {
//                    DesignationSummary newSummary = new DesignationSummary();
//                    newSummary.setBillGenerateTableId(billGenerateTableId);
//                    newSummary.setDesignation(designation);
//                    newSummary.setNumberOfEmployees(1);
//                    newSummary.setTotalRate(rate);
//                    newSummary.setTotalAmount(totalAmount);
//                    designationSummaryMap.put(designation, newSummary);
//                }
//            }
//        }
//
//        List<DesignationSummary> savedDesignationSummaries = designationSummaryRepository.saveAll(designationSummaryMap.values());
//
//        return savedDesignationSummaries;
//    }








//    public List<DesignationSummary> calculateAndSaveDesignationSummary(int billGenerateTableId) {
//        List<BGTable> bgTableEntries = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
//
//        Map<String, DesignationSummary> designationSummaryMap = new HashMap<>();
//
//        // Fetch existing DesignationSummary records that match the billGenerateTableId
//        List<DesignationSummary> existingDesignationSummaries = designationSummaryRepository.findByBillGenerateTableId(billGenerateTableId);
//
//        for (BGTable bgTableEntry : bgTableEntries) {
//            ProjectEmployees projectEmployees = bgTableEntry.getProjectEmployees();
//            Employee employee = projectEmployees.getEmployee();
//            String designation = employee.getDesignation();
//            int rate = bgTableEntry.getRate();
//            int totalAmount = bgTableEntry.getTotalAmount();
//
//            boolean entryExists = false;
//
//            for (DesignationSummary existingSummary : existingDesignationSummaries) {
//                // Check if a matching entry already exists
//                String existingDesignation = existingSummary.getDesignation();
//
//                if (existingSummary.getDesignation().equalsIgnoreCase(designation)) {
//                    entryExists = true;
//                    break;
//                }
//                System.out.println("Existing Designation: " + existingDesignation);
//                System.out.println("New Designation: " + designation);
//            }
//
//            if (!entryExists) {
//                if (designationSummaryMap.containsKey(designation)) {
//                    DesignationSummary existingSummary = designationSummaryMap.get(designation);
//                    existingSummary.setNumberOfEmployees(existingSummary.getNumberOfEmployees() + 1);
//                    existingSummary.setTotalRate(existingSummary.getTotalRate() + rate);
//                    existingSummary.setTotalAmount(existingSummary.getTotalAmount() + totalAmount);
//                } else {
//                    DesignationSummary newSummary = new DesignationSummary();
//                    newSummary.setBillGenerateTableId(billGenerateTableId);
//                    newSummary.setDesignation(designation);
//                    newSummary.setNumberOfEmployees(1);
//                    newSummary.setTotalRate(rate);
//                    newSummary.setTotalAmount(totalAmount);
//                    designationSummaryMap.put(designation, newSummary);
//                }
//            }
//        }
//
//        List<DesignationSummary> savedDesignationSummaries = designationSummaryRepository.saveAll(designationSummaryMap.values());
//
//        return savedDesignationSummaries;
//    }


}

