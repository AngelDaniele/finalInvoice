package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.BGTableRepository;
import com.demo.GenerateInvoiceFinal.Repository.DescriptionRepository;
import com.demo.GenerateInvoiceFinal.Repository.PerDiemCostRepository;
import com.demo.GenerateInvoiceFinal.model.BGTable;
import com.demo.GenerateInvoiceFinal.model.Description;
import com.demo.GenerateInvoiceFinal.model.PerDiemCost;
import com.demo.GenerateInvoiceFinal.model.UnionDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class UnionDTOService {


    @Autowired
    private BGTableRepository bgTableRepository;
    @Autowired
    private PerDiemCostRepository perDiemCostRepository;

    @Autowired
    DescriptionRepository descriptionRepository;

    public List<UnionDTO> getUnionDTOsByBillGenerateTableId(int billGenerateTableId) {
        // Query BGTable based on billGenerateTableId
        List<BGTable> bgTableList = bgTableRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);

        // Create a list to store UnionDTO instances
        List<UnionDTO> unionDTOList = new ArrayList<>();


        // Iterate through the list (assuming you want to handle multiple BGTable entries)
        for (BGTable bgTable : bgTableList) {
            // Create UnionDTO for each BGTable entry
            UnionDTO unionDTO = new UnionDTO();
            // Extract and set Item field from BGTable
            if (bgTable != null && bgTable.getProjectEmployees() != null
                    && bgTable.getProjectEmployees().getEmployee() != null) {
                unionDTO.setItem(bgTable.getProjectEmployees().getEmployee().getTechnology());
            }
            unionDTO.setDescription(bgTable.getDescription());
            unionDTO.setStartDate(bgTable.getProjectEmployees().getStartDate());
            unionDTO.setEndDate(bgTable.getBillGenerate().getBillGenerateEndDate());
            unionDTO.setSAC(bgTable.getSAC());
            unionDTO.setQuantity(bgTable.getTotalDays());
            unionDTO.setRate(bgTable.getRate());
            unionDTO.setAmount(bgTable.getTotalAmount());
            unionDTOList.add(unionDTO);
        }

            List<PerDiemCost> perDiemCostList = perDiemCostRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
            for (PerDiemCost perDiemCost : perDiemCostList) {
                UnionDTO unionDTO = new UnionDTO();
            unionDTO.setItem(perDiemCost.getProjectEmployees().getEmployee().getTechnology());
            unionDTO.setDescription(perDiemCost.getDescription());
            unionDTO.setStartDate(perDiemCost.getProjectEmployees().getStartDate());
            unionDTO.setEndDate(perDiemCost.getBillGenerate().getBillGenerateEndDate());
            unionDTO.setSAC(perDiemCost.getSAC());
            unionDTO.setQuantity(perDiemCost.getNumberOfDays());
            unionDTO.setRate(perDiemCost.getProjectEmployees().getProjectHeadCount().getProject().getCostPerDiem());
            unionDTO.setAmount(perDiemCost.getTotalAmount());

                // Set other fields from BGTable or other entities if needed...

                // Add the UnionDTO to the list
                unionDTOList.add(unionDTO);
            }

            List<Description>descriptionList=descriptionRepository.findAllByBillGenerate_BillGenerateTableId(billGenerateTableId);
            for(Description description : descriptionList){
                UnionDTO unionDTO = new UnionDTO();

                unionDTO.setDescription(description.getDescription());
                unionDTO.setStartDate(description.getDate());
                unionDTO.setQuantity(1);
                unionDTO.setRate(description.getAmount());
                unionDTO.setAmount(description.getAmount());
                unionDTO.setSAC(description.getSAC());
                unionDTOList.add(unionDTO);

            }

        return unionDTOList;
    }

}