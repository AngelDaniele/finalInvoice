package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="Client")
public class Client {




        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name="clientTableId")
        private  int clientTableId;

        @Column(name="clientId")
        private String clientId;

        @Column(name="clientName")
        private String  clientName;

        @Column(name="clientAddress")
        private String clientAddress;

        @Column(name="phoneNumber")
        private String  phoneNumber;

        @Column(name="gmailId")
        private String  gmailId;

    @Column(name="userId")
    private String userId;

    @Column(name="timeStamp")
    private LocalDateTime timeStamp;


        public int getClientTableId() {
            return clientTableId;
        }

        public void setClientTableId(int clientTableId) {
            this.clientTableId = clientTableId;
        }

        public String getClientId() {
            return clientId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String getClientName() {
            return clientName;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public String getClientAddress() {
            return clientAddress;
        }

        public void setClientAddress(String clientAddress) {
            this.clientAddress = clientAddress;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public String getGmailId() {
            return gmailId;
        }

        public void setGmailId(String gmailId) {
            this.gmailId = gmailId;
        }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public LocalDateTime getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(LocalDateTime timeStamp) {
        this.timeStamp = timeStamp;
    }
}


