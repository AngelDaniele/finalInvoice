package com.demo.GenerateInvoiceFinal.Service;


import com.demo.GenerateInvoiceFinal.Exception.EmployeeNotFoundException;
import com.demo.GenerateInvoiceFinal.Exception.ProjectNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.*;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BillGenerateService {

    @Autowired
    DescriptionRepository descriptionRepository;

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private ProjectEmployeeRepository projectEmployeesRepository;

    @Autowired
    private BillGenerateRepository billGenerateRepository;
    @Autowired
    ProjectEmployeeService projectEmployeeService;
    @Autowired
    EmployeeWorkingRepository employeeWorkingRepository;


    @Autowired
    private BGTableRepository bgTableRepository;

    @Autowired
    private SubProjectRepository subProjectRepository;

    @Autowired
    private    PerDiemCostRepository    perDiemCostRepository;
    @Autowired
    private ProjectEmployeeRepository projectEmployeeRepository;
    @Autowired
    ProjectHeadCountRepository projectHeadCountRepository;


    public BillGenerate saveBillGenerate(BillGenerateUI billGenerateUI, String userId) {
        // Fetch Project details based on projectId
        Project project = projectRepository.findByProjectId(billGenerateUI.getProjectId());

        // Create a new BillGenerate object
        BillGenerate billGenerate = new BillGenerate();
        billGenerate.setProject(project);
        billGenerate.setBillGenerateStartDate(billGenerateUI.getBillGenerateStartDate());
        billGenerate.setBillGenerateEndDate(billGenerateUI.getBillGenerateEndDate());
        billGenerate.setUserId(userId);
        billGenerate.setTimeStamp(LocalDateTime.now());
        billGenerate.setSAC(billGenerateUI.getSAC());
        // Set other properties as needed

        // Save BillGenerate object
        billGenerate = billGenerateRepository.save(billGenerate);

        // Create a new BGTable object
        BGTable bgTable = new BGTable();
        bgTable.setBillGenerate(billGenerate);
        // Set other properties from BillGenerateUI as needed

        // Fetch ProjectHeadCount based on project
        List<ProjectHeadCount> projectHeadCountList = projectHeadCountRepository.findByProject(project);

        // List to store the BGTable objects
        List<BGTable> bgTableList = new ArrayList<>();

        // Handle the list of ProjectHeadCount based on your business logic
        BGTable bgTableEntry = null;
        for (ProjectHeadCount projectHeadCount : projectHeadCountList) {
            // Fetch ProjectEmployees based on projectHeadCountId
            List<ProjectEmployees> projectEmployeesList = (List<ProjectEmployees>) projectEmployeesRepository.findByProjectHeadCount(projectHeadCount);

            // Handle the list of ProjectEmployees based on your business logic
            for (ProjectEmployees projectEmployees : projectEmployeesList) {
                LocalDate projectEmployeeStartDate = projectEmployees.getStartDate();
//                LocalDate billGenerateStartDate = billGenerateUI.getBillGenerateStartDate();
                LocalDate billGenerateEndDate = billGenerateUI.getBillGenerateEndDate();

//                long totalDays = calculateTotalDays(projectEmployeeStartDate, billGenerateStartDate, billGenerateEndDate);
//                LocalDate projectEmployeeStartDate = projectEmployees.getStartDate();
                long totalDays = 0;
                if (projectEmployeeStartDate != null) {
                    projectEmployeeStartDate = projectEmployeeStartDate.withYear(billGenerateUI.getBillGenerateStartDate().getYear()).withMonth(billGenerateUI.getBillGenerateStartDate().getMonthValue());
                    totalDays = calculateTotalDays(projectEmployeeStartDate, billGenerateUI.getBillGenerateStartDate(), billGenerateEndDate);
                    // Rest of your code...
                } else {
                    // Handle the case where projectEmployeeStartDate is null
                }


                // Create a new BGTable object for each ProjectEmployees
                bgTableEntry = new BGTable();
                bgTableEntry.setBillGenerate(billGenerate);
                bgTableEntry.setProjectEmployees(projectEmployees);
                bgTableEntry.setRate(projectHeadCount.getRate());
//                bgTableEntry.setSAC();
                bgTableEntry.setTotalDays((int) totalDays);
                bgTableEntry.setTotalAmount(bgTableEntry.getTotalDays() * bgTableEntry.getRate());
                bgTableEntry.setSAC(billGenerateUI.getSAC());
                // Add BGTable object to the list
                bgTableList.add(bgTableEntry);
                bgTableRepository.saveAll(bgTableList);

                PerDiemCost perDiemCost = new PerDiemCost();
                perDiemCost.setBillGenerate(billGenerate);
                perDiemCost.setProjectEmployees(bgTableEntry.getProjectEmployees());
//                                        perDiemCost.setNumberOfDays(totalDays);
//                                        perDiemCost.setTotalAmount(totalAmount);


                perDiemCostRepository.save(perDiemCost);
            }
        }




        return billGenerate;
    }





    private long calculateTotalDays(LocalDate projectEmployeeStartDate, LocalDate billGenerateStartDate, LocalDate billGenerateEndDate) {
        // Extract the year and month components from projectEmployeeStartDate
        YearMonth projectEmployeeYearMonth = YearMonth.from(projectEmployeeStartDate);

        // Extract the year and month components from billGenerateStartDate
        YearMonth billGenerateYearMonth = YearMonth.from(billGenerateStartDate);

        // Check if the month and year of projectEmployeeStartDate match billGenerateStartDate
        if (projectEmployeeYearMonth.equals(billGenerateYearMonth)) {
            long totalDays = ChronoUnit.DAYS.between(
                    projectEmployeeStartDate,
                    billGenerateEndDate
            ) + 1;

            // Exclude weekends (Saturdays and Sundays)
            long businessDays = totalDays - countWeekendDays(projectEmployeeStartDate, billGenerateEndDate);

            return businessDays;
        } else {
            // If the months and years don't match, return 0 days
            return 0;
        }
    }

    private long countWeekendDays(LocalDate startDate, LocalDate endDate) {
        long weekendDays = 0;
        LocalDate currentDate = startDate;

        while (!currentDate.isAfter(endDate)) {
            DayOfWeek dayOfWeek = currentDate.getDayOfWeek();
            if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
                weekendDays++;
            }
            currentDate = currentDate.plusDays(1);
        }

        return weekendDays;
    }


    public List<BillGenerate> getAllBillGenerates() {
        return billGenerateRepository.findAll();
    }

    public BillGenerate getBillGenerateDatesById(int billGenerateTableId) {
        return billGenerateRepository.findById(billGenerateTableId).orElse(null);
    }



    public List<BillGenerate> getBillGenerateByProjectId(String projectId) {
        return billGenerateRepository.findByProject_ProjectId(projectId);
    }

    public BillGenerate getBillGenerateById(Integer billGenerateTableId) {
        return billGenerateRepository.findByBillGenerateTableId(billGenerateTableId);
    }


//
//    public List<Object> getUnionDataByBillGenerateTableId(Integer billGenerateTableId) {
//        List<Object> unionData = bgTableRepository.findUnionDataByBillGenerateTableId(billGenerateTableId);
//        unionData.addAll(descriptionRepository.findUnionDataByBillGenerateTableId(billGenerateTableId));
//        unionData.addAll(perDiemCostRepository.findUnionDataByBillGenerateTableId(billGenerateTableId));
//        return unionData;
//    }
    }


//    public BillGenerate saveBillGenerate(BillGenerateUI billGenerateUI) {
//        // Fetch Project details based on projectId
//        Project project = projectRepository.findByProjectId(billGenerateUI.getProjectId());
//
//        // Create a new BillGenerate object
//        BillGenerate billGenerate = new BillGenerate();
//        billGenerate.setProject(project);
//        billGenerate.setBillGenerateStartDate(billGenerateUI.getBillGenerateStartDate());
//        billGenerate.setBillGenerateEndDate(billGenerateUI.getBillGenerateEndDate());
//        // Set other properties as needed
//
//        // Save BillGenerate object
//        billGenerate = billGenerateRepository.save(billGenerate);
//
//        // Create a new BGTable object
//        BGTable bgTable = new BGTable();
//        bgTable.setBillGenerate(billGenerate);
//        // Set other properties from BillGenerateUI as needed
//        ProjectHeadCount projectHeadCount = projectHeadCountRepository.findByProject(project);
//
//        // Fetch ProjectEmployees based on projectHeadCountId
//        List<ProjectEmployees> projectEmployeesList = (List<ProjectEmployees>) projectEmployeesRepository.findByProjectHeadCount(projectHeadCount);
//
//        // Handle the list of ProjectEmployees based on your business logic
//        for (ProjectEmployees projectEmployees : projectEmployeesList) {
//            // Create a new BGTable object for each ProjectEmployees
//            BGTable bgTableEntry = new BGTable();
//            bgTableEntry.setBillGenerate(billGenerate);
//            bgTableEntry.setProjectEmployees(projectEmployees);
//            // Set other properties from BillGenerateUI as needed
//
//            // Save each BGTable object
//            bgTableRepository.save(bgTableEntry);
//        }
//
//        // Return the saved BillGenerate object
//        return billGenerate;
//    }

//    public BillGenerate saveBillGenerate(BillGenerateUI billGenerateUI) {
//        // Fetch Project details based on projectId
//        Project project = projectRepository.findByProjectId(billGenerateUI.getProjectId());
//
//        // Create a new BillGenerate object
//        BillGenerate billGenerate = new BillGenerate();
//        billGenerate.setProject(project);
//        billGenerate.setBillGenerateStartDate(billGenerateUI.getBillGenerateStartDate());
//        billGenerate.setBillGenerateEndDate(billGenerateUI.getBillGenerateEndDate());
//        // Set other properties as needed
//
//        // Save BillGenerate object
//        billGenerate = billGenerateRepository.save(billGenerate);
//
//        // Create a new BGTable object
//        BGTable bgTable = new BGTable();
//        bgTable.setBillGenerate(billGenerate);
//        // Set other properties from BillGenerateUI as needed
//        ProjectHeadCount projectHeadCount = projectHeadCountRepository.findByProject(project);
//
//        // Fetch ProjectEmployees based on projectHeadCountId
//        ProjectEmployees projectEmployees = projectEmployeesRepository.findByProjectHeadCount(projectHeadCount);
//
//        // Set projectEmployeeId in bgTable
//        bgTable.setProjectEmployees(projectEmployees);
//
//        // Update BGTable object
//
//        // Save BGTable object
//        bgTableRepository.save(bgTable);
//
//        // Return the saved BillGenerate object
//        return billGenerate;
//    }

//    public BillGenerate saveBillGenerateUI(BillGenerateUI billGenerateUI) {
//        Project project = projectRepository.findByProjectId(billGenerateUI.getProjectId());
//
//        if (project != null) {
//            LocalDate billGenerateStartDate = billGenerateUI.getBillGenerateStartDate();
//            LocalDate billGenerateEndDate = billGenerateUI.getBillGenerateEndDate();
//
//            // Check if billGenerateStartDate and billGenerateEndDate are within project's date range
//            if (isDateWithinRange(billGenerateStartDate, project.getStartDate(), project.getEndDate())
//                    && isDateWithinRange(billGenerateEndDate, project.getStartDate(), project.getEndDate())) {
//
//                // Check if the date range already exists in the billgenerate table
//                boolean dateRangeExists = billGenerateRepository.existsByProjectAndBillGenerateStartDateAndBillGenerateEndDate(
//                        project, billGenerateStartDate, billGenerateEndDate);
//
//                if (!dateRangeExists) {
////                    List<ProjectEmployees> projectEmployeesList = projectEmployeeService.getAllProjectEmployeesByProjectId(project.getProjectId());
//
//                    if (!projectEmployeesList.isEmpty()) {
//                        boolean hasNonZeroValues = false; // Flag to check if any non-zero values were encountered
//                        BillGenerate billGenerate = new BillGenerate();
//                        billGenerate.setProject(project);
//                        billGenerate.setBillGenerateStartDate(billGenerateStartDate);
//                        billGenerate.setBillGenerateEndDate(billGenerateEndDate);
//
//                        billGenerate = billGenerateRepository.save(billGenerate);
//
//                        List<SubProject> subProjects = subProjectRepository.findByProject_ProjectId(project.getProjectId());
//
//                        Map<String, Integer> designationCounts = new HashMap<>();
//
//                        // Calculate counts for each designation
//                        for (ProjectEmployees projectEmployee : projectEmployeesList) {
//                            Employee employee = projectEmployee.getEmployee();
//
//                            if (employee != null) {
//                                String designation = employee.getDesignation();
//                                designationCounts.put(designation, designationCounts.getOrDefault(designation, 0) + 1);
//                            } else {
//                                throw new EmployeeNotFoundException("Project is not yet assigned");
//                            }
//                        }
//
//                        for (ProjectEmployees projectEmployee : projectEmployeesList) {
//                            Employee employee = projectEmployee.getEmployee();
//
//                            if (employee != null) {
//                                String designation = employee.getDesignation();
//                                int count = designationCounts.get(designation);
//
//                                SubProject subProject = getSubProjectForEmployee(projectEmployee, subProjects,billGenerate.getBillGenerateStartDate(),billGenerate.getBillGenerateEndDate());
//
//                                if (subProject != null) {
//                                    // Calculate rates based on subproject details and divide equally
//                                    long subProjectDuration = ChronoUnit.DAYS.between(
//                                            subProject.getStartDate(), subProject.getEndDate()) + 1;
//
//                                    double rate;
//                                    if (designation.equals("Technical Lead")) {
//                                        rate = 0.50 * subProject.getBudget() / subProjectDuration;
//                                    } else if (designation.equals("Junior Software Analyst")) {
//                                        rate = 0.20 * subProject.getBudget() / subProjectDuration;
//                                    } else if (designation.equals("Senior Software Analyst")) {
//                                        rate = 0.30 * subProject.getBudget() / subProjectDuration;
//                                    } else {
//
//                                        rate = 0.0;
//                                    }
//
//                                    // Divide the rate equally among employees with the same designation
//                                    int finalRate = count > 0 ? (int) (rate / count) : 0;
//                                    if (rate != 0.0) {
//                                        BGTable bgTable = new BGTable();
//                                        bgTable.setBillGenerate(billGenerate);
//                                        bgTable.setProjectEmployees(projectEmployee);
//                                        bgTable.setRate(finalRate);
//
//                                        // Calculate and set totalDays based on the dates from EmployeeWorking
//                                        int totalDays = calculateTotalDays(projectEmployee, billGenerateStartDate, billGenerateEndDate);
//                                        bgTable.setTotalDays(totalDays);
//
//                                        int totalAmount = totalDays * finalRate;
//                                        bgTable.setTotalAmount(totalAmount);
//                                        billGenerate.setBillGenerateAmount(billGenerate.getBillGenerateAmount() + totalAmount);
//                                        subProject.setRemaindingBudget(subProject.getRemaindingBudget() - totalAmount);
//
//
//                                        project.setRemaindingBudget(project.getRemaindingBudget() - totalAmount);
//                                        billGenerate.setRemaindingBudget(project.getRemaindingBudget());
//
//                                        // Check if any non-zero values were encountered
//                                        if (finalRate != 0 || totalAmount != 0) {
//                                            hasNonZeroValues = true;
//                                        }
//                                        // Log values for debugging
//                                        System.out.println("Rate: " + rate);
//                                        System.out.println("Count: " + count);
//                                        System.out.println("FinalRate: " + finalRate);
//                                        System.out.println("TotalAmount: " + totalAmount);
//
//                                        bgTableRepository.save(bgTable);
//                                        PerDiemCost perDiemCost = new PerDiemCost();
//                                        perDiemCost.setBillGenerate(billGenerate);
//                                        perDiemCost.setProjectEmployees(projectEmployee);
////
//                                        perDiemCostRepository.save(perDiemCost);
//                                    }else{
//                                        throw new ProjectNotFoundException(" rate is zero ");                                    }
//                                } else {
//                                    throw new ProjectNotFoundException("SubProject not found for ProjectEmployee: ");
//                                }
//                            } else {
//                                throw new EmployeeNotFoundException("Project is not yet assigned");
//                            }
//                        }
//
//                        // Check if any non-zero values were encountered before returning
//                        if (hasNonZeroValues) {
//                            projectRepository.save(project);
//                            return billGenerate;
//                        } else {
//                            // No non-zero values encountered, delete the BillGenerate entry
//                            billGenerateRepository.delete(billGenerate);
//                            return null;
//                        }
//                    } else {
//                        throw new EmployeeNotFoundException("Project is not yet assigned");
//                    }
//                } else {
//                    throw new IllegalArgumentException("The date range already exists in the billgenerate table");
//                }
//            } else {
//                throw new IllegalArgumentException("billGenerateStartDate or billGenerateEndDate is not within project startDate and endDate");
//            }
//        } else {
//            throw new ProjectNotFoundException("Project not found");
//        }
//    }
//
//



    // Helper method to check if a date is within a date range (inclusive)
//    private boolean isDateWithinRange(LocalDate date, LocalDate startDate, LocalDate endDate) {
//        return !date.isBefore(startDate) && !date.isAfter(endDate);
//    }



    // Helper method to get the subproject associated with a ProjectEmployee
//    private SubProject getSubProjectForEmployee(ProjectEmployees projectEmployee, List<SubProject> subProjects, LocalDate billGenerateStartDate, LocalDate billGenerateEndDate) {
//        for (SubProject subProject : subProjects) {
//            LocalDate subProjectStartDate = subProject.getStartDate();
//            LocalDate subProjectEndDate = subProject.getEndDate();
//
//            // Check if the subProject's dates overlap with or are contained within the billGenerateStartDate and billGenerateEndDate
//            if (!billGenerateStartDate.isAfter(subProjectEndDate) && !billGenerateEndDate.isBefore(subProjectStartDate)) {
//                return subProject;
//            }
//        }
//        return null;
//    }






    // Helper method to calculate total days based on EmployeeWorking dates
//    private int calculateTotalDays(ProjectEmployees projectEmployee, LocalDate startDate, LocalDate endDate) {
//        List<EmployeeWorking> employeeWorkingList = employeeWorkingRepository.findByProjectEmployeesAndDateBetween(
//                projectEmployee, startDate, endDate);
//        return employeeWorkingList.size();
//    }





//
//    private int calculateTotalDays(ProjectEmployees projectEmployee, LocalDate startDate, LocalDate endDate) {
//        // Find all EmployeeWorking records for the given ProjectEmployee within the specified date range
//        List<EmployeeWorking> employeeWorkingList = employeeWorkingRepository.findByProjectEmployeesAndDateBetween(
//                projectEmployee, startDate, endDate);
//
//        // Calculate the total number of days worked
//        int totalDaysWorked = 0;
//
//        // Iterate through the list of EmployeeWorking records and count the days
//        for (EmployeeWorking employeeWorking : employeeWorkingList) {
//            // Assuming EmployeeWorking has a LocalDate field called "workingDate"
//            LocalDate workingDate = employeeWorking.getDate();
//
//            // Check if the working date is within the specified date range
//            if (!workingDate.isBefore(startDate) && !workingDate.isAfter(endDate)) {
//                totalDaysWorked++;
//            }
//        }
//
//        // Log the parameters and the size of the result set
//        System.out.println("Project Employee ID: " + projectEmployee.getProjectEmployeeId());
//        System.out.println("Start Date: " + startDate);
//        System.out.println("End Date: " + endDate);
//        System.out.println("Total Days Worked: " + totalDaysWorked);
//        for (EmployeeWorking employeeWorking : employeeWorkingList) {
//            System.out.println("EmployeeWorking Date: " + employeeWorking.getDate());
//        }
//
//
//        return totalDaysWorked;
//    }







































