package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.DescriptionService;
import com.demo.GenerateInvoiceFinal.model.Description;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/descriptions")
public class DescriptionController {

    @Autowired
     DescriptionService descriptionService;

    @PostMapping("/save/{billGenerateTableId}")
        public ResponseEntity<List<Description>> saveDescriptionWithBillGenerate(
                @RequestBody Object requestBody,
                @PathVariable Integer billGenerateTableId
        ) {
            List<Description> savedDescriptions = descriptionService.saveDescriptionsWithBillGenerate(requestBody, billGenerateTableId);
            return new ResponseEntity<>(savedDescriptions, HttpStatus.CREATED);
        }


    @GetMapping("/all")
    public List<Description> getAllDescriptions() {
        return descriptionService.getAllDescriptions();
    }


    @GetMapping("/byBillGenerateTableId/{billGenerateTableId}")
    public List<Description> getDescriptionsByBillGenerateTableId(@PathVariable Integer billGenerateTableId) {
        return descriptionService.getDescriptionsByBillGenerateTableId(billGenerateTableId);
    }


    }



