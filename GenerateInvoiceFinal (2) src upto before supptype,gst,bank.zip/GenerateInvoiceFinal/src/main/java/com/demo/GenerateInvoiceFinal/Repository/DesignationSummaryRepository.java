package com.demo.GenerateInvoiceFinal.Repository;


import com.demo.GenerateInvoiceFinal.model.DesignationSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface DesignationSummaryRepository extends JpaRepository<DesignationSummary,Integer> {


    List<DesignationSummary> findByBillGenerateTableId(int billGenerateTableId);
}
