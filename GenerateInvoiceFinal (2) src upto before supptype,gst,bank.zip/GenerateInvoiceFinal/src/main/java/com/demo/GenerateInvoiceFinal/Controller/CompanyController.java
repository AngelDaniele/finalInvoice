package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.ClientService;
import com.demo.GenerateInvoiceFinal.Service.CompanyService;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/company")
public class CompanyController {

    @Autowired
    CompanyService companyService;


    @GetMapping("/{companyTableId}")
    public ResponseEntity<Company> getCompanyById(@PathVariable int companyTableId) {
        Optional<Company> company = companyService.getCompanyById(companyTableId);
        return company.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }



}
