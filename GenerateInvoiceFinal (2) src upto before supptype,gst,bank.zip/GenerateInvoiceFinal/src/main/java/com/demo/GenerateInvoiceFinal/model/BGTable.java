package com.demo.GenerateInvoiceFinal.model;

        import javax.persistence.*;
        import java.time.LocalDate;

@Entity
@Table(name = "BGTable")
public class BGTable {






    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bgTableId")
    private int bgTableId;

    @ManyToOne
    @JoinColumn(name = "billGenerateTableId")
    private BillGenerate billGenerate;

    @ManyToOne
    @JoinColumn(name = "projectEmployeeId")
    private ProjectEmployees projectEmployees;



    @Column(name = "totalDays")
    private int totalDays;

    @Column(name = "totalAmount")
    private int totalAmount;

    @Column(name = "rate")
    private int rate;

    @Column(name="SAC")
    private Integer SAC;

    @Column(name="description")
    private String description;

    public int getBgTableId() {
        return bgTableId;
    }

    public void setBgTableId(int bgTableId) {
        this.bgTableId = bgTableId;
    }

    public BillGenerate getBillGenerate() {
        return billGenerate;
    }

    public void setBillGenerate(BillGenerate billGenerate) {
        this.billGenerate = billGenerate;
    }

    public ProjectEmployees getProjectEmployees() {
        return projectEmployees;
    }

    public void setProjectEmployees(ProjectEmployees projectEmployees) {
        this.projectEmployees = projectEmployees;
    }



    public int getTotalDays() {
        return totalDays;
    }

    public void setTotalDays(int totalDays) {
        this.totalDays = totalDays;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getSAC() {
        return SAC;
    }

    public void setSAC(Integer SAC) {
        this.SAC = SAC;
    }
}


