package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Repository.*;
import com.demo.GenerateInvoiceFinal.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProjectHeadCountService {

    @Autowired
    ProjectHeadCountRepository designation1Repository;

    @Autowired
    ProjectRepository projectRepository;


    @Autowired
    Designation2Repository designation2Repository;


@Autowired
    DesignationRepository designationRepository;

@Autowired
    ProjectEmployeeRepository projectEmployeeRepository;

    public List<ProjectHeadCount> saveDesignation1List(int projectId, List<ProjectHeadCountRequest> designation1Requests) {
        List<ProjectHeadCount> savedDesignation1List = new ArrayList<>();

        // Fetch the existing project by projectId
        Optional<Project> existingProject = projectRepository.findById(projectId);

        for (ProjectHeadCountRequest designation1Request : designation1Requests) {
            // Check if all fields are null or 0
            if (designation1Request.getOnsiteOrOffsite() == null &&
                    designation1Request.getNumberOfResource() == 0 &&
                    designation1Request.getRate() == 0 &&
                    designation1Request.getLocation() == null &&
                    designation1Request.getDesignationId() == 0) {
                // Skip saving if all fields are null or 0
                continue;
            }
            ProjectHeadCount designation1 = new ProjectHeadCount();
            designation1.setOnsiteOrOffsite(designation1Request.getOnsiteOrOffsite());
            designation1.setNumberOfResource(designation1Request.getNumberOfResource());
            designation1.setRate(designation1Request.getRate());
            designation1.setLocation(designation1Request.getLocation());

            // Set the existing project
            designation1.setProject(existingProject.get());

            // Fetch the existing designation by DesignationId
            Optional<Designation> existingDesignation = designationRepository.findById(designation1Request.getDesignationId());

            if (existingDesignation.isPresent()) {
                designation1.setDesignation(existingDesignation.get());
            }

            // Save the Designation1 entity
            ProjectHeadCount savedDesignation1 = designation1Repository.save(designation1);
            savedDesignation1List.add(savedDesignation1);

            // Create ProjectEmployees objects based on numberOfResource
            for (int i = 0; i < designation1.getNumberOfResource(); i++) {
                ProjectEmployees projectEmployees = new ProjectEmployees();

                projectEmployees.setProjectHeadCount(savedDesignation1);
                // Set other properties as needed

                // Save the ProjectEmployees entity
                projectEmployeeRepository.save(projectEmployees);
            }
        }

        return savedDesignation1List;
    }



//
//    public List<ProjectHeadCount> saveDesignation1List(int projectId, List<Designation1Request> designation1Requests) {
//        List<ProjectHeadCount> savedDesignation1List = new ArrayList<>();
//
//        // Fetch the existing project by projectId
//        Optional<Project> existingProject = projectRepository.findById(projectId);
//
//        for (Designation1Request designation1Request : designation1Requests) {
//            // Check if all fields are null or 0
//            if (designation1Request.getOnsiteOrOffsite() == null &&
//                    designation1Request.getNumberOfResource() == 0 &&
//                    designation1Request.getRate() == 0 &&
//                    designation1Request.getLocation() == null &&
//                    designation1Request.getDesignationId() == 0) {
//                // Skip saving if all fields are null or 0
//                continue;
//            }
//            ProjectHeadCount designation1 = new ProjectHeadCount();
//            designation1.setOnsiteOrOffsite(designation1Request.getOnsiteOrOffsite());
//            designation1.setNumberOfResource(designation1Request.getNumberOfResource());
//            designation1.setRate(designation1Request.getRate());
//            designation1.setLocation(designation1Request.getLocation());
//
//            // Set the existing project
//            designation1.setProject(existingProject.get());
//
//            // Fetch the existing designation by DesignationId
//            Optional<Designation> existingDesignation = designationRepository.findById(designation1Request.getDesignationId());
//
//            if (existingDesignation.isPresent()) {
//                designation1.setDesignation(existingDesignation.get());
//            }
//
//            // Save the Designation1 entity
//            ProjectHeadCount savedDesignation1 = designation1Repository.save(designation1);
//            savedDesignation1List.add(savedDesignation1);
//        }
//
//        return savedDesignation1List;
//    }
    public List<ProjectHeadCount> getAllDesignation1() {
        return designation1Repository.findAll();
    }

//    public List<Designation1> getDesignation1ByProjectId(String projectId) {
//        return designation1Repository.findByProjectProjectId(projectId);
//    }





//
//    public List<Designation1> saveDesignation1List(List<Designation1> designation1List, int projectTableId) {
//        List<Designation1> savedDesignation1List = new ArrayList<>();
//        List<Designation2> savedDesignation2List = new ArrayList<>(); // Create a list for Designation2 records
//
//
//        Optional<Project> existingProject = projectRepository.findByProjectTableId(projectTableId);
//
//        for (Designation1 designation1 : designation1List) {
//            if (existingProject.isPresent()) {
//
//                designation1.setProject(existingProject.get());
//            } else {
//
//                Project newProject = new Project();
//                newProject.setProjectTableId(projectTableId);
//                designation1.setProject(newProject);
//            }
//
//
//            Designation1 savedDesignation1 = designation1Repository.save(designation1);
//            savedDesignation1List.add(savedDesignation1);
//
//
//
//
//            int numberOfResource = designation1.getNumberOfResource();
//            if (numberOfResource > 0) {
//                for (int i = 0; i < numberOfResource; i++) {
//                    Designation2 designation2 = new Designation2();
//                    // Copy fields from Designation1 to Designation2
////                    designation2.setDesignation1(savedDesignation1);
//                    designation2.setDesignation(designation1.getDesignation());
//                    designation2.setOnsiteOrOffsite(designation1.getOnsiteOrOffsite());
//                    designation2.setRate(designation1.getRate());
//                    designation2.setLocation(designation1.getLocation());
////                    designation2.setProject(designation1.getProject());
//
//
//                    Designation2 savedDesignation2 = designation2Repository.save(designation2);
//                    savedDesignation2List.add(savedDesignation2);
//
//
//                }
//            }
//        }
//
//        return savedDesignation1List;
//    }



}
