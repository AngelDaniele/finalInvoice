package com.demo.GenerateInvoiceFinal.model;

import java.time.LocalDate;

public class ProjectWithClientIdRequest {
    private String projectId;
    private String projectName;
    private LocalDate startDate;
    private LocalDate endDate;
    private int budget;
    private String clientId;
   private boolean checkBox;
    private int costPerDiem;
    private String tdm;
    private String currency;


    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public int getBudget() {
        return budget;
    }

    public void setBudget(int budget) {
        this.budget = budget;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public boolean isCheckBox() {
        return checkBox;
    }

    public void setCheckBox(boolean checkBox) {
        this.checkBox = checkBox;
    }

    public int getCostPerDiem() {
        return costPerDiem;
    }

    public void setCostPerDiem(int costPerDiem) {
        this.costPerDiem = costPerDiem;
    }

    public String getTdm() {
        return tdm;
    }

    public void setTdm(String tdm) {
        this.tdm = tdm;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
