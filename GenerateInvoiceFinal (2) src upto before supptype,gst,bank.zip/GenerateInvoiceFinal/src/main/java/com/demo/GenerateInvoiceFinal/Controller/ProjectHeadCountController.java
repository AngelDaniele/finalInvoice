package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.ProjectHeadCountService;


import com.demo.GenerateInvoiceFinal.model.ProjectHeadCount;
import com.demo.GenerateInvoiceFinal.model.ProjectHeadCountRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/designation1Controller")
public class ProjectHeadCountController {
    @Autowired
    private ProjectHeadCountService designation1Service;

//    @PostMapping("/save-list")
//    public ResponseEntity<List<Designation1>> saveDesignation1List(@RequestBody List<Designation1> designation1List) {
//        List<Designation1> savedDesignations = designation1Service.saveDesignation1List(designation1List);
//        return ResponseEntity.ok(savedDesignations);
//    }

    @PostMapping("/saveList/{projectId}")
    public ResponseEntity<List<ProjectHeadCount>> saveDesignation1List(
            @PathVariable int projectId,
            @RequestBody List<ProjectHeadCountRequest> designation1Requests) {
        List<ProjectHeadCount> savedDesignation1List = designation1Service.saveDesignation1List(projectId, designation1Requests);
        return new ResponseEntity<>(savedDesignation1List, HttpStatus.CREATED);
    }

//    @GetMapping("/getAll")
//    public ResponseEntity<List<Designation1>> getAllDesignation1() {
//        List<Designation1> allDesignation1 = designation1Service.getAllDesignation1();
//        return ResponseEntity.ok(allDesignation1);
//    }

//    @GetMapping("/byProjectId/{projectId}")
//    public List<Designation1> getDesignation1ByProjectId(@PathVariable String projectId) {
//        return designation1Service.getDesignation1ByProjectId(projectId);
//    }
}
