package com.demo.GenerateInvoiceFinal.model;

import java.time.LocalDate;

public class UpdatedProjectEmployee {



    private String employee;
    private LocalDate startDate;
    private LocalDate endDate;

    // Constructors, getters, and setters

    public UpdatedProjectEmployee() {
    }

    public UpdatedProjectEmployee(String employee, LocalDate startDate, LocalDate endDate) {
        this.employee = employee;
        this.startDate = startDate;
        this.endDate = endDate;
    }


    public String getEmployee() {
        return employee;
    }

    public void setEmployee(String employee) {
        this.employee = employee;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
}
