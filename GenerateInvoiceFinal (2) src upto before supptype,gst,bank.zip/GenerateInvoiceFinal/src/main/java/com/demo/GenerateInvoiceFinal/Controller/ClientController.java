package com.demo.GenerateInvoiceFinal.Controller;


import com.demo.GenerateInvoiceFinal.Service.ClientService;
import com.demo.GenerateInvoiceFinal.model.BillGenerate;
import com.demo.GenerateInvoiceFinal.model.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/client")
public class ClientController {

    @Autowired
    ClientService clientService;

    @PostMapping("/saveclient/{userId}")
    public Client saveClient(@RequestBody Client client,@PathVariable String userId) {

        return clientService.saveClient(client,userId);
    }


    @GetMapping("/allclient")
    public List<Client> getAllclient(){

        return clientService.getAllClient();
    }


    @PutMapping("/updateclient/{key}")
    public ResponseEntity<Client> updateClient(@RequestBody Client client,@PathVariable int key) {

        Client client1 = clientService.updateProductInCatalog(client,key);

        return new ResponseEntity<Client>(client1, HttpStatus.OK);

    }



    @DeleteMapping("/deleteclient/{id}")
    public ResponseEntity<String> deleteClient(@PathVariable("id") Integer id) {

        String res = clientService.deleteClient(id);
        return new ResponseEntity<String>(res, HttpStatus.OK);

    }


    @GetMapping("/{clientTableId}")
    public ResponseEntity<Client> getClientById(@PathVariable int clientTableId) {
        Client client  = clientService.getClientById(clientTableId);
        return new ResponseEntity<Client>(client, HttpStatus.FOUND);
    }

}
