package com.demo.GenerateInvoiceFinal.Controller;

import com.demo.GenerateInvoiceFinal.Service.SupplyTypeService;
import com.demo.GenerateInvoiceFinal.model.Project;
import com.demo.GenerateInvoiceFinal.model.SupplyType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/supplyType")
public class SupplyTypeController {


    @Autowired
    SupplyTypeService supplyTypeService;

    @GetMapping("/allSupplyType")
    public List<SupplyType> getAllSupplyType(){

        return supplyTypeService.getAllSupplyType();
    }

}
