package com.demo.GenerateInvoiceFinal.Service;

import com.demo.GenerateInvoiceFinal.Exception.ProjectNotFoundException;
import com.demo.GenerateInvoiceFinal.Exception.SupplyTypeNotFoundException;
import com.demo.GenerateInvoiceFinal.Repository.SupplyTypeRepository;
import com.demo.GenerateInvoiceFinal.model.Project;
import com.demo.GenerateInvoiceFinal.model.SupplyType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplyTypeService {

    @Autowired
    SupplyTypeRepository supplyTypeRepository;



    public List<SupplyType> getAllSupplyType() {

        List<SupplyType> list = supplyTypeRepository.findAll();

        if (list.size() > 0) {
            return list;
        } else
            throw new SupplyTypeNotFoundException("No supplyType in catalog");
    }




}
