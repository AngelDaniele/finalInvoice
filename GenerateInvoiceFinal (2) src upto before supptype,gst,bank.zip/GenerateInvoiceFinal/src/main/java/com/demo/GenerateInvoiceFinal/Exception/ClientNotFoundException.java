package com.demo.GenerateInvoiceFinal.Exception;

public class ClientNotFoundException extends RuntimeException  {


    public ClientNotFoundException(String message){
        super(message);
    }
}







