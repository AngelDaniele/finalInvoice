package com.demo.GenerateInvoiceFinal.Repository;


import com.demo.GenerateInvoiceFinal.model.BGTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BGTableRepository extends JpaRepository<BGTable,Integer> {



//    @Query("SELECT b FROM BGTable b WHERE b.billGenerate.billGenerateTableId = :billGenerateTableId")
//    List<BGTable> findByBillGenerateTableId(@Param("billGenerateTableId") Integer billGenerateTableId);
    List<BGTable> findAllByBillGenerate_BillGenerateTableId(int billGenerateTableId);

//    List<Object> findUnionDataByBillGenerateTableId(Integer billGenerateTableId);

//  List<Object> findUnionDataByBillGenerateTableId(Integer billGenerateTableId);

//    @Query("SELECT b FROM BGTable b WHERE b.billGenerate.billGenerateTableId = :billGenerateTableId")
//    List<Object> findUnionDataByBillGenerateTableId(@Param("billGenerateTableId") Integer billGenerateTableId);
}
