package com.demo.GenerateInvoiceFinal.model;

import javax.persistence.*;

@Entity
@Table(name="GST")
public class GST {


        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "gstId")
        private int gstId;

        @Column(name = "gstTaxType")
        private String gstTaxType;

        @Column(name = "gstTaxPercentage")
        private double gstTaxPercentage;

        public GST() {
        }

        // Getters and setters

        public int getGstId() {
            return gstId;
        }

        public void setGstId(int gstId) {
            this.gstId = gstId;
        }

        public String getGstTaxType() {
            return gstTaxType;
        }

        public void setGstTaxType(String gstTaxType) {
            this.gstTaxType = gstTaxType;
        }

        public double getGstTaxPercentage() {
            return gstTaxPercentage;
        }

        public void setGstTaxPercentage(double gstTaxPercentage) {
            this.gstTaxPercentage = gstTaxPercentage;
        }
    }




